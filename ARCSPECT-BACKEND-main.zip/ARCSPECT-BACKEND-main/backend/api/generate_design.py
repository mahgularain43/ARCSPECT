import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from fastapi.responses import JSONResponse

from backend.db import chat_history_collection
from backend.utils import get_current_user
from backend.pipeline import full_pipeline

router = APIRouter()

class PromptInput(BaseModel):
    prompt: str

@router.post("/generate-design")
async def generate_design(
    payload: PromptInput,
    user: dict = Depends(get_current_user),
):
    try:
        user_input = payload.prompt.strip()
        if not user_input:
            raise HTTPException(status_code=400, detail="Prompt cannot be empty")

        # Use full UUID string for uniqueness; slicing to 8 chars may risk collisions
        scene_id = str(uuid.uuid4())

        # Run pipeline to generate the floorplan image
        relative_image_path = full_pipeline(user_input, scene_id)

        # Construct full URL to serve the image (update host in production)
        full_image_url = f"http://localhost:8000/static/{relative_image_path}"

        # Save the design record in MongoDB with UTC datetime object (better for querying)
        chat_history_collection.insert_one({
            "user_id": user["_id"],
            "prompt": user_input,
            "message": "Design generated successfully",
            "image": full_image_url,
            "scene_id": scene_id,
            "timestamp": datetime.utcnow()
        })

        return JSONResponse({
            "message": "Design generated successfully",
            "image_url": full_image_url,
            "scene_id": scene_id
        })

    except HTTPException:
        # Re-raise HTTP exceptions without modification
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Design generation failed: {str(e)}")

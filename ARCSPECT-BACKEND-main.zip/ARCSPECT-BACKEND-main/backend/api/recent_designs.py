from fastapi import APIRouter, Query, HTTPException
from backend.db import chat_history_collection

router = APIRouter()

@router.get("/recent-designs")
async def get_recent_designs(limit: int = Query(10, ge=1, le=100)):
    try:
        results = chat_history_collection.find().sort("timestamp", -1).limit(limit)
        designs = [
            {
                "prompt": doc.get("prompt"),
                "scene_id": doc.get("scene_id"),
                "image": doc.get("image"),
                "timestamp": doc.get("timestamp"),
                "user_id": str(doc.get("user_id")) if doc.get("user_id") else None
            }
            for doc in results
        ]
        return {"designs": designs}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch recent designs: {str(e)}")

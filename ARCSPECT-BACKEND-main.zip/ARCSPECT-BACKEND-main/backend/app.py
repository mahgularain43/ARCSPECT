from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

# Import routers
from backend.auth import router as auth_router
from backend.routes.chat import router as chat_router
from backend.api.generate_design import router as generate_design_router
from backend.api.recent_designs import router as recent_designs_router  # Import recent designs router

app = FastAPI()

# Static files serving
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
os.makedirs(STATIC_DIR, exist_ok=True)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# CORS middleware (allow all origins for now, adjust in production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Replace with frontend URL(s) in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers with /api prefix where needed
app.include_router(auth_router)
app.include_router(chat_router)
app.include_router(generate_design_router, prefix="/api")
app.include_router(recent_designs_router, prefix="/api")  # Mount recent designs API under /api

# Health check route
@app.get("/")
def root():
    return {"status": "Backend is running"}

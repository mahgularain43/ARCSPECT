from fastapi import APIRouter, Request, HTTPException, status
from pydantic import BaseModel, EmailStr
from uuid import uuid4
from backend.db import users_collection

router = APIRouter(prefix="/auth")

# ✅ Models
class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class RegisterRequest(BaseModel):
    username: str
    email: EmailStr
    password: str


# ✅ Register custom user (for email/password signups)
@router.post("/register")
async def register(data: RegisterRequest):
    existing_user = users_collection.find_one({"email": data.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered.")

    user_id = str(uuid4())
    new_user = {
        "_id": user_id,
        "email": data.email,
        "username": data.username,
        "password": data.password  # ⚠️ Remember to hash passwords in production!
    }

    users_collection.insert_one(new_user)
    print(f"✅ Registered user: {data.email} ({user_id})")
    return {"message": "User registered successfully", "user_id": user_id}


# ✅ Login custom user (returns token = _id)
@router.post("/login")
async def login(data: LoginRequest):
    user = users_collection.find_one({"email": data.email})
    if user and user["password"] == data.password:
        return {"access_token": user["_id"], "token_type": "bearer"}
    raise HTTPException(status_code=401, detail="Invalid credentials")


# ✅ Auth middleware for DB users only (no Firebase)
def get_current_user(request: Request) -> dict:
    token = request.headers.get("Authorization")
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing token")

    token = token.replace("Bearer ", "").strip()

    # 🔐 Validate token as user _id in DB
    user = users_collection.find_one({"_id": token})
    if user:
        return {"_id": user["_id"], "email": user["email"]}

    raise HTTPException(status_code=401, detail="Invalid or expired token")

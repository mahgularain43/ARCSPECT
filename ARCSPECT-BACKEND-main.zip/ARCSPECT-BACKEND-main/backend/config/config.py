# backend/config/config.py

class Config:
    data_dir = "backend/data"
    linguistic_dir = f"{data_dir}/linguistic"
    scene_graph_dir = f"{data_dir}/scene_graphs"
    label_image_dir = f"{data_dir}/label_images"
    mask_image_dir = f"{data_dir}/mask_images"
    split_dir = f"{data_dir}/splits"
    processed_dir = f"{data_dir}/processed"

    # Training params
    train_ids = f"{split_dir}/train_ids.txt"
    test_ids = f"{split_dir}/test_ids.txt"
    max_rooms = 10
    room_classes = 7
    max_seq_len = 128
    batch_size = 4
    hidden_dim = 256
    dropout = 0.3
    lr = 2e-5
    epochs = 10

    # Output
    best_model_path = "backend/models/weights/text2graph_best.pth"



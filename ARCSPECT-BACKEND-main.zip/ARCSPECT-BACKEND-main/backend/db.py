from pymongo import MongoClient
import os
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
client = MongoClient(MONGO_URI)
db = client["userDatabase"]

users_collection = db["users"]
chat_history_collection = db["chat_history"]

# Optional connection test
try:
    client.admin.command("ping")
    print("MongoDB connected successfully!")
except Exception as e:
    print(f"MongoDB connection error: {e}")

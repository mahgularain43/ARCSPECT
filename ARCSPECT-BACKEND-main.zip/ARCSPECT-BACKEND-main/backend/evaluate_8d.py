from parser.scene_graph_to_pyg import load_scene_graph_txt

data = load_scene_graph_txt("static/outputs/0af62f8d/0af62f8d_layout.json")
print(data)

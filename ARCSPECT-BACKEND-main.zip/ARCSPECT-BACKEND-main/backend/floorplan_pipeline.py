import os
import json
import re
import uuid
import numpy as np
from shapely.geometry import box, LineString, Point, Polygon
from shapely.ops import unary_union
import networkx as nx
import svgwrite
from fuzzywuzzy import process
from dotenv import load_dotenv
from groq import Groq
from typing import List, Optional, Dict

load_dotenv()
client = Groq(api_key=os.getenv("GROQ_API_KEY"))

# ---- LLM parsing and JSON extraction ----
def extract_strict_json(text: str) -> dict | None:
    import json, re
    try:
        json_block = re.search(r'```(?:json)?\s*({[\s\S]*?})\s*```', text)
        if json_block:
            text = json_block.group(1)
        else:
            start_idx = text.find('{')
            if start_idx == -1:
                print("❌ Could not find JSON object in LLM output.")
                print("🔎 Raw Text:\n", text)
                return None
            text = text[start_idx:]
        text = re.sub(r',\s*(\}|\])', r'\1', text)
        def balance_brackets(s, open_c, close_c):
            count_open = s.count(open_c)
            count_close = s.count(close_c)
            diff = count_open - count_close
            if diff > 0:
                s += close_c * diff
            return s
        text = balance_brackets(text, '{', '}')
        text = balance_brackets(text, '[', ']')
        return json.loads(text.strip())
    except Exception as e:
        print(f"❌ JSON extraction error: {e}")
        print(f"🔎 Raw fallback text:\n{text}")
        return None

def sanitize_room(room: dict) -> dict:
    try:
        name = str(room.get("name", f"room_{uuid.uuid4().hex[:4]}"))
    except Exception:
        name = f"room_{uuid.uuid4().hex[:4]}"
    try:
        width = max(0.1, float(room.get("width", 2.0)))
    except Exception:
        width = 2.0
    try:
        height = max(0.1, float(room.get("height", 2.0)))
    except Exception:
        height = 2.0
    return {"name": name, "width": width, "height": height}

def is_valid_room(room: dict) -> bool:
    return "name" in room and isinstance(room.get("name"), str) and room.get("name").strip() != ""

def get_scene_graph_from_llm(prompt: str, retries=3) -> dict:
    for attempt in range(1, retries + 1):
        print(f"🔍 Requesting scene graph from LLM (attempt {attempt})...")
        try:
            response = client.chat.completions.create(
                model="llama3-70b-8192",
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are a smart house planner. Respond ONLY with valid JSON inside a code block.\n"
                            "Format:\n"
                            "{\n"
                            "  \"rooms\": [\n"
                            "    {\"name\": \"bedroom1\", \"width\": 0.25, \"height\": 0.2}\n"
                            "  ],\n"
                            "  \"connections\": [\n"
                            "    [\"bedroom1\", \"kitchen1\"]\n"
                            "  ]\n"
                            "}\n"
                            "Notes:\n"
                            "- Each room must have name, width, and height only.\n"
                            "- If missing fields, defaults will be used.\n"
                            "- Connections are pairs of room names.\n"
                        ),
                    },
                    {"role": "user", "content": prompt},
                ],
                temperature=0.2,
            )
            raw_output = response.choices[0].message.content.strip()
            print("🔎 Raw LLM Output:\n", raw_output)
            parsed = extract_strict_json(raw_output)
            if not parsed:
                raise ValueError("❌ Failed to parse JSON from LLM.")
            raw_rooms = parsed.get("rooms", [])
            valid_rooms = [sanitize_room(r) for r in raw_rooms if is_valid_room(r)]
            if not valid_rooms:
                raise ValueError("❌ No valid rooms after sanitization.")
            raw_conns = parsed.get("connections", [])
            valid_conns = [c for c in raw_conns if isinstance(c, list) and len(c) == 2]
            scene_graph = {"rooms": valid_rooms, "connections": valid_conns}
            print("✅ Final Scene Graph:\n", json.dumps(scene_graph, indent=2))
            return scene_graph
        except Exception as e:
            print(f"❌ Attempt {attempt} failed: {e}")
            if attempt == retries:
                print("❌ Max retries reached. Returning empty graph.")
                return {"rooms": [], "connections": []}

# --- Geometry & SVG pipeline code from before ---

def iou(box1: Polygon, box2: Polygon) -> float:
    inter = box1.intersection(box2).area
    union = box1.union(box2).area
    return inter / union if union > 0 else 0

def resolve_overlaps(boxes: List[Polygon], iterations=50, move_step=0.002) -> List[Polygon]:
    if not boxes: return []
    for _ in range(iterations):
        overlaps = False
        new_boxes = []
        for i, b1 in enumerate(boxes):
            shift_x, shift_y = 0, 0
            for j, b2 in enumerate(boxes):
                if i != j and b1.intersects(b2):
                    overlaps = True
                    dx = b1.centroid.x - b2.centroid.x
                    dy = b1.centroid.y - b2.centroid.y
                    shift_x += move_step if dx > 0 else -move_step
                    shift_y += move_step if dy > 0 else -move_step
            minx, miny, maxx, maxy = b1.bounds
            new_boxes.append(box(minx + shift_x, miny + shift_y, maxx + shift_x, maxy + shift_y))
        boxes = new_boxes
        if not overlaps:
            break
    return boxes

def grid_align_boxes(boxes: List[Polygon], grid_step=0.05) -> List[Polygon]:
    def snap(v): return round(v / grid_step) * grid_step
    aligned = []
    for b in boxes:
        minx, miny, maxx, maxy = b.bounds
        aligned.append(box(snap(minx), snap(miny), snap(maxx), snap(maxy)))
    return aligned

def force_wall_alignment(boxes: List[Polygon], tol=0.02) -> List[Polygon]:
    if not boxes: return []
    all_x, all_y = [], []
    for b in boxes:
        minx, miny, maxx, maxy = b.bounds
        all_x.extend([minx, maxx])
        all_y.extend([miny, maxy])
    def cluster_and_avg(coords):
        coords = sorted(set(coords))
        groups = []
        while coords:
            base = coords.pop(0)
            group = [base]
            while coords and abs(coords[0]-base)<=tol:
                group.append(coords.pop(0))
            groups.append(round(sum(group)/len(group), 4))
        return groups
    snapped_x = cluster_and_avg(all_x)
    snapped_y = cluster_and_avg(all_y)
    def snap_val(v, group): return min(group, key=lambda ref: abs(v-ref))
    aligned = []
    for b in boxes:
        minx, miny, maxx, maxy = b.bounds
        aligned.append(box(
            snap_val(minx, snapped_x),
            snap_val(miny, snapped_y),
            snap_val(maxx, snapped_x),
            snap_val(maxy, snapped_y)
        ))
    return aligned

def relational_align_boxes(pred_array: np.ndarray, scene_graph: Dict, spacing=0.1) -> List[Polygon]:
    positions = {}
    placed = set()
    room_sizes = {i: (w,h) for i,(x,y,w,h) in enumerate(pred_array)}
    adjacency = {i: [] for i in range(len(pred_array))}
    for edge in scene_graph.get("edges", []):
        src, tgt = edge.get("source"), edge.get("target")
        dir_hint = edge.get("direction", "right")
        adjacency[src].append((tgt, dir_hint))
    def place(idx, x, y):
        if idx in placed: return
        w,h = room_sizes[idx]
        positions[idx] = box(x,y,x+w,y+h)
        placed.add(idx)
        for tgt, dir_hint in adjacency.get(idx, []):
            if tgt in placed: continue
            tw, th = room_sizes[tgt]
            if dir_hint=="right": nx, ny = x+w+spacing, y
            elif dir_hint=="left": nx, ny = x - tw - spacing, y
            elif dir_hint=="below": nx, ny = x, y + h + spacing
            elif dir_hint=="above": nx, ny = x, y - th - spacing
            else: nx, ny = x+w+spacing, y
            place(tgt, nx, ny)
    place(0, 0, 0)
    return [positions.get(i, box(0,0,0.4,0.4)) for i in range(len(pred_array))]

def build_adjacency_graph(polygons: List[Polygon], tol=1e-5) -> nx.Graph:
    G = nx.Graph()
    for i,p1 in enumerate(polygons):
        G.add_node(i, polygon=p1)
        for j in range(i+1,len(polygons)):
            p2 = polygons[j]
            inter = p1.boundary.intersection(p2.boundary)
            if not inter.is_empty and inter.length > tol:
                G.add_edge(i,j, shared_boundary=inter)
    return G

def find_doors_with_semantic_links(graph: nx.Graph, room_labels: List[str], semantic_links: List[Dict], door_length_ratio=0.3, min_door_spacing=0.01) -> List[LineString]:
    doors = []
    door_positions = []
    label_to_nodes = {}
    for idx, label in enumerate(room_labels):
        label_lower = label.lower()
        label_to_nodes.setdefault(label_lower, []).append(idx)
    for link in semantic_links:
        src_idx, tgt_idx = link.get("source"), link.get("target")
        if not isinstance(src_idx,int) or not isinstance(tgt_idx,int): continue
        for u in label_to_nodes.get(room_labels[src_idx].lower(), []):
            for v in label_to_nodes.get(room_labels[tgt_idx].lower(), []):
                if graph.has_edge(u,v):
                    shared = graph[u][v].get("shared_boundary")
                    if shared is None: continue
                    lines = [shared] if shared.geom_type=='LineString' else list(shared.geoms)
                    for line in lines:
                        if line.length < 1e-5: continue
                        mid = line.interpolate(0.5, normalized=True)
                        if any(mid.distance(p) < min_door_spacing for p in door_positions): continue
                        vx, vy = line.coords[-1][0] - line.coords[0][0], line.coords[-1][1] - line.coords[0][1]
                        mag = (vx**2 + vy**2)**0.5
                        vx, vy = vx/mag, vy/mag
                        door_len = line.length * door_length_ratio
                        dx0, dy0 = mid.x - (door_len/2)*vx, mid.y - (door_len/2)*vy
                        dx1, dy1 = mid.x + (door_len/2)*vx, mid.y + (door_len/2)*vy
                        doors.append(LineString([(dx0,dy0),(dx1,dy1)]))
                        door_positions.append(mid)
    return doors

def generate_windows_for_exterior_walls(polygons: List[Polygon], wall_margin=0.01) -> List[LineString]:
    windows = []
    union_poly = unary_union(polygons)
    for p in polygons:
        coords = list(p.exterior.coords)
        for i in range(len(coords)-1):
            edge = (coords[i], coords[i+1])
            midpoint = Point((edge[0][0]+edge[1][0])/2,(edge[0][1]+edge[1][1])/2)
            if not union_poly.contains(midpoint):
                windows.append(LineString(edge))
    return windows

def draw_double_walls(dwg, polygons, scale, offset_x, offset_y, height, wall_thickness=0.05):
    from shapely.geometry import LineString
    for poly in polygons:
        coords = list(poly.exterior.coords)
        n = len(coords)
        for i in range(n-1):
            p1, p2 = coords[i], coords[i+1]
            line = LineString([p1,p2])
            left_line = line.parallel_offset(wall_thickness*scale, 'left')
            right_line = line.parallel_offset(wall_thickness*scale, 'right')
            for l in [left_line, right_line]:
                if l.geom_type == 'LineString':
                    pts = [(x + offset_x, height - (y + offset_y)) for x,y in l.coords]
                    dwg.add(dwg.polyline(points=pts, stroke='#003366', stroke_width=2, fill='none'))

def draw_door_swing_arcs(dwg, doors, scale, offset_x, offset_y, height):
    from math import atan2, cos, sin, radians
    for door in doors:
        x0,y0 = door.coords[0]
        x1,y1 = door.coords[1]
        cx = x0*scale + offset_x
        cy = height - (y0*scale + offset_y)
        dx = (x1 - x0)*scale
        dy = (y1 - y0)*scale
        angle = atan2(dy, dx)
        radius = door.length*scale
        start_x = cx
        start_y = cy
        end_x = cx + radius*cos(angle + radians(90))
        end_y = cy + radius*sin(angle + radians(90))
        path_str = f"M {start_x} {start_y} A {radius} {radius} 0 0 1 {end_x} {end_y}"
        dwg.add(dwg.path(d=path_str, stroke='#444', fill='none', stroke_width=1.5, stroke_dasharray='5,3'))

def generate_svg_floorplan(polygons: List[Polygon], doors: List[LineString], labels: List[str], save_path: str,
                           scale=100, margin=50, windows: Optional[List[LineString]]=None) -> None:
    all_x, all_y = [], []
    for poly in polygons:
        xs, ys = poly.exterior.xy
        all_x.extend(xs)
        all_y.extend(ys)
    width = (max(all_x) - min(all_x))*scale + 2*margin
    height = (max(all_y) - min(all_y))*scale + 2*margin
    offset_x = -min(all_x)*scale + margin
    offset_y = -min(all_y)*scale + margin

    dwg = svgwrite.Drawing(save_path, size=(width, height))
    dwg.add(dwg.rect(insert=(0,0), size=(width,height), fill='white'))

    # Fill rooms lightly
    for poly,label in zip(polygons,labels):
        pts = [((x*scale)+offset_x, height - ((y*scale)+offset_y)) for x,y in poly.exterior.coords]
        dwg.add(dwg.polygon(pts, fill='#cce5ff', stroke='none'))

    # Draw double walls
    draw_double_walls(dwg, polygons, scale, offset_x, offset_y, height)

    # Draw doors
    for door in doors:
        if not isinstance(door, LineString): continue
        x0,y0 = door.coords[0]
        x1,y1 = door.coords[1]
        start = (x0*scale + offset_x, height - (y0*scale + offset_y))
        end = (x1*scale + offset_x, height - (y1*scale + offset_y))
        dwg.add(dwg.line(start=start, end=end, stroke='white', stroke_width=8))

    # Door swing arcs
    draw_door_swing_arcs(dwg, doors, scale, offset_x, offset_y, height)

    # Windows
    if windows:
        for window in windows:
            if not isinstance(window, LineString): continue
            x0,y0 = window.coords[0]
            x1,y1 = window.coords[1]
            start = (x0*scale + offset_x, height - (y0*scale + offset_y))
            end = (x1*scale + offset_x, height - (y1*scale + offset_y))
            dwg.add(dwg.line(start=start, end=end, stroke='blue', stroke_width=4, stroke_dasharray='10,5'))

    # Room labels with dimensions
    for poly,label in zip(polygons,labels):
        minx,miny,maxx,maxy = poly.bounds
        cx = (minx+maxx)/2*scale + offset_x
        cy = height - ((miny+maxy)/2*scale + offset_y)
        width_m = maxx - minx
        height_m = maxy - miny
        dwg.add(dwg.text(label.capitalize(), insert=(cx,cy-10),
                         text_anchor='middle', font_size=16, fill='#003366', font_family='Arial', font_weight='bold'))
        dim_text = f"{width_m:.2f}m × {height_m:.2f}m"
        dwg.add(dwg.text(dim_text, insert=(cx,cy+10),
                         text_anchor='middle', font_size=12, fill='#555555', font_family='Arial'))

    dwg.save()

def export_floorplan_to_json(boxes: List[Polygon], labels: List[str], save_path: str) -> None:
    layout = []
    for i, b in enumerate(boxes):
        minx, miny, maxx, maxy = b.bounds
        layout.append({
            "id": i,
            "label": labels[i],
            "x": float(minx),
            "y": float(miny),
            "width": float(maxx - minx),
            "height": float(maxy - miny)
        })
    dir_path = os.path.dirname(save_path)
    if dir_path:
        os.makedirs(dir_path, exist_ok=True)
    with open(save_path, 'w') as f:
        json.dump(layout, f, indent=2)

# --- Infer directions between nodes by their coordinates ---
def infer_edge_directions(nodes, edges):
    directions = []
    for e in edges:
        src = nodes[e["source"]]
        tgt = nodes[e["target"]]
        dx = tgt["coordinates"]["x"] - src["coordinates"]["x"]
        dy = tgt["coordinates"]["y"] - src["coordinates"]["y"]
        if abs(dx) > abs(dy):
            direction = "right" if dx > 0 else "left"
        else:
            direction = "below" if dy > 0 else "above"
        directions.append({"source": e["source"], "target": e["target"], "direction": direction})
    return directions

# --- Integration entrypoint ---
def generate_floorplan_from_prompt(user_prompt: str, output_svg_path: str):
    # Get scene graph from LLM
    scene_graph = get_scene_graph_from_llm(user_prompt)
    if not scene_graph.get("rooms"):
        print("❌ No rooms found in LLM output.")
        return

    nodes = scene_graph["rooms"]
    connections = scene_graph.get("connections", [])

    # Build nodes list with ids and coords for direction inference
    nodes_with_id = []
    for i, room in enumerate(nodes):
        nodes_with_id.append({
            "id": i,
            "name": room["name"],
            "coordinates": {"x": 0, "y": 0},  # Will be assigned below
            "dimensions": {"width": room["width"], "height": room["height"]},
        })

    # Infer 2D layout with networkx spring layout or linear if needed
    room_names = [n["name"] for n in nodes_with_id]
    G = nx.Graph()
    G.add_nodes_from(room_names)
    for conn in connections:
        if len(conn) >= 2:
            for i in range(len(conn)-1):
                G.add_edge(conn[i], conn[i+1])
    pos = nx.spring_layout(G, k=1.0, iterations=50, seed=42)
    spacing = 2.0
    for i, n in enumerate(nodes_with_id):
        x, y = pos.get(n["name"], (i*spacing, -spacing))
        n["coordinates"]["x"] = round(x * spacing, 3)
        n["coordinates"]["y"] = round(y * spacing, 3)

    # Prepare rooms and edges for postprocessing
    raw_rooms = []
    for n in nodes_with_id:
        raw_rooms.append({"label": n["name"], "width": n["dimensions"]["width"], "height": n["dimensions"]["height"]})

    # Edges with inferred directions
    id_map = {n["name"]: n["id"] for n in nodes_with_id}
    edges = []
    for conn in connections:
        if len(conn) >= 2:
            for i in range(len(conn)-1):
                src_id = id_map.get(conn[i])
                tgt_id = id_map.get(conn[i+1])
                if src_id is not None and tgt_id is not None:
                    edges.append({"source": src_id, "target": tgt_id})
    edges_with_dirs = infer_edge_directions(nodes_with_id, edges)
    semantic_graph = {"edges": edges_with_dirs}

    # Generate floorplan
    generate_floorplan_from_raw(raw_rooms, semantic_graph, output_svg_path)

def generate_floorplan_from_raw(raw_rooms: List[Dict], semantic_graph: Dict, output_svg_path: str):
    pred_array = []
    labels = []
    for r in raw_rooms:
        pred_array.append([0,0,r['width'],r['height']])
        labels.append(r['label'])

    aligned_boxes = relational_align_boxes(np.array(pred_array), semantic_graph)
    resolved_boxes = resolve_overlaps(aligned_boxes, iterations=100, move_step=0.002)
    grid_boxes = grid_align_boxes(resolved_boxes, grid_step=0.05)
    final_boxes = force_wall_alignment(grid_boxes, tol=0.02)

    adj_graph = build_adjacency_graph(final_boxes)
    doors = find_doors_with_semantic_links(adj_graph, labels, semantic_graph.get("edges", []))
    windows = generate_windows_for_exterior_walls(final_boxes)

    generate_svg_floorplan(final_boxes, doors, labels, output_svg_path, scale=100, margin=50, windows=windows)

    layout_json_path = output_svg_path.replace(".svg", ".json")
    export_floorplan_to_json(final_boxes, labels, layout_json_path)
    print(f"SVG floorplan saved: {output_svg_path}")
    print(f"Layout JSON saved: {layout_json_path}")

if __name__ == "__main__":
    prompt = """
    Design a house with two bedrooms, one kitchen, and a living room. Bedrooms should be adjacent, kitchen next to living room.
    """
    generate_floorplan_from_prompt(prompt, "output_floorplan.svg")

import svgwrite

def draw_floorplan_svg(rooms, filename="floorplan.svg", scale=100):
    """
    Draw floorplan as SVG using room polygons, doors, windows.
    
    :param rooms: List of dicts with 'name', 'polygon', 'doors', 'windows'
    :param filename: Output SVG filename
    :param scale: Scale factor from unit to pixels
    """
    # Find bounding box
    all_x = [x for room in rooms for (x, y) in room["polygon"]]
    all_y = [y for room in rooms for (x, y) in room["polygon"]]
    width = (max(all_x) - min(all_x)) * scale + 100
    height = (max(all_y) - min(all_y)) * scale + 100
    
    dwg = svgwrite.Drawing(filename, size=(width, height))
    
    # Background
    dwg.add(dwg.rect(insert=(0, 0), size=(width, height), fill='white'))
    
    # Offset to leave margin
    offset_x = -min(all_x) * scale + 50
    offset_y = -min(all_y) * scale + 50
    
    for room in rooms:
        points = [((x * scale) + offset_x, (height - (y * scale)) - offset_y) for x, y in room["polygon"]]
        
        # Draw room polygon
        dwg.add(
            dwg.polygon(points,
                        fill="#cce5ff",
                        stroke="#003366",
                        stroke_width=3)
        )
        
        # Draw doors as white rectangles overlaying walls
        for door in room.get("doors", []):
            d1, d2 = door
            door_points = [
                ((d1[0] * scale) + offset_x, height - (d1[1] * scale) - offset_y),
                ((d2[0] * scale) + offset_x, height - (d2[1] * scale) - offset_y)
            ]
            # Draw door line (you can enhance this to door shape)
            dwg.add(
                dwg.line(start=door_points[0], end=door_points[1],
                         stroke='white', stroke_width=8)
            )
        
        # Add room label text in approximate center
        xs = [p[0] for p in points]
        ys = [p[1] for p in points]
        cx = sum(xs) / len(xs)
        cy = sum(ys) / len(ys)
        dwg.add(
            dwg.text(room["name"], insert=(cx, cy),
                     text_anchor="middle",
                     alignment_baseline="middle",
                     font_size=20,
                     fill="#003366")
        )
    
    dwg.save()
    print(f"SVG floorplan saved to {filename}")

# Example usage:
rooms_example = [
    {
        "name": "Living Room",
        "polygon": [(0, 0), (5, 0), (5, 4), (0, 4)],
        "doors": [((1, 0), (2, 0))]
    },
    {
        "name": "Kitchen",
        "polygon": [(5, 0), (7, 0), (7, 3), (5, 3)],
        "doors": [((5, 1), (5, 2))]
    }
]

draw_floorplan_svg(rooms_example)

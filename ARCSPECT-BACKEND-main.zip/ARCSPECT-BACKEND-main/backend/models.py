from sqlalchemy import Column, Integer, String, Float, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()

class HousePlan(Base):
    __tablename__ = 'house_plans'
    
    id = Column(Integer, primary_key=True)
    description = Column(String)
    scene_graph = Column(JSON)  # Store the parsed scene graph
    layout_data = Column(JSON)  # Store the generated layout
    
    rooms = relationship("Room", back_populates="house_plan")

class Room(Base):
    __tablename__ = 'rooms'
    
    id = Column(Integer, primary_key=True)
    house_plan_id = Column(Integer, ForeignKey('house_plans.id'))
    room_type = Column(String)
    area = Column(Float)
    position_x = Column(Float)
    position_y = Column(Float)
    
    house_plan = relationship("HousePlan", back_populates="rooms")

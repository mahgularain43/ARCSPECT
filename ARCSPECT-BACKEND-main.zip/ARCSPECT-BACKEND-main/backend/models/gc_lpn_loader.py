# models/gc_lpn_loader.py

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from models.model_LSTM import LayoutGeneratorLite
from utils.graph_utils import one_hot_room_vector, build_adjacency_matrix


class GCNLayer(nn.Module):
    def __init__(self, in_features, out_features):
        super(GCNLayer, self).__init__()
        self.linear = nn.Linear(in_features, out_features)
        
    def forward(self, x, adj):
        x = self.linear(x)
        x = torch.matmul(adj, x)
        return F.relu(x)

class GCLPN(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(GCLPN, self).__init__()
        self.gcn1 = GCNLayer(input_dim, hidden_dim)
        self.gcn2 = GCNLayer(hidden_dim, hidden_dim)
        self.gcn3 = GCNLayer(hidden_dim, output_dim)
        
    def forward(self, x, adj):
        x = self.gcn1(x, adj)
        x = self.gcn2(x, adj)
        x = self.gcn3(x, adj)
        return x

def load_gc_lpn_model(model_path=None):
    """
    Load or initialize the GC-LPN model
    """
    model = GCLPN(
        input_dim=64,    # Input feature dimension
        hidden_dim=128,  # Hidden layer dimension
        output_dim=4     # Output dimension (x, y, width, height)
    )
    
    if model_path and torch.cuda.is_available():
        model.load_state_dict(torch.load(model_path))
    elif model_path:
        model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
    
    return model

class GCLPNWrapper:
    def __init__(self, model_path: str, device: str = None):
        """
        Initializes the GC-LPN model for layout generation.
        Args:
            model_path (str): Path to the pretrained generator_best.pth
            device (str): 'cuda' or 'cpu'. Defaults to auto-selection.
        """
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model = self._load_model(model_path)

    def _load_model(self, weights_path: str):
        model = LayoutGeneratorLite(
            input_size=8,  # 7 one-hot room types + 1 position/size
            image_height=64,
            image_width=64,
            channel=3,
            num_layer=1
        )

        checkpoint = torch.load(weights_path, map_location=self.device)
        model.load_state_dict(checkpoint["model"], strict=False)
        model.eval()
        model.to(self.device)

        return model

    def predict_layout(self, graph: dict) -> dict:
        """
        Predicts bounding boxes from a scene graph using GC-LPN.

        Args:
            graph (dict): Must contain 'nodes' and 'edges'

        Returns:
            dict: {
                "bounding_boxes": List of [x1, y1, x2, y2],
                "room_types": List of room type strings (aligned to boxes)
            }
        """
        assert "nodes" in graph and "edges" in graph, "Invalid scene graph format"

        features = np.array([one_hot_room_vector(n) for n in graph["nodes"]])
        adj = build_adjacency_matrix(len(graph["nodes"]), graph["edges"])

        features_tensor = torch.FloatTensor(features).unsqueeze(0).to(self.device)  # (1, N, D)
        adj_tensor = torch.FloatTensor(adj).unsqueeze(0).to(self.device)            # (1, N, N)

        with torch.no_grad():
            output = self.model(features_tensor, adj_tensor)  # (1, N, 4)
            boxes = output.squeeze(0).cpu().tolist()

        room_types = [n["type"] for n in graph["nodes"]]

        return {
            "bounding_boxes": boxes,
            "room_types": room_types
        }

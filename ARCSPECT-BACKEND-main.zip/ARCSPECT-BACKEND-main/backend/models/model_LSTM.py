import torch
import torch.nn as nn

class LayoutGeneratorLite(nn.Module):
    def __init__(self, input_size, image_height, image_width, channel=3, num_layer=1):
        super(LayoutGeneratorLite, self).__init__()
        self.input_size = input_size
        self.hidden_size = 128
        self.num_layer = num_layer
        
        # LSTM for processing room sequence
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=self.hidden_size,
            num_layers=num_layer,
            batch_first=True
        )
        
        # Fully connected layers for box prediction
        self.fc_layers = nn.Sequential(
            nn.Linear(self.hidden_size, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 4)  # x, y, width, height
        )
        
    def forward(self, x, adj=None):
        # Process through LSTM
        lstm_out, _ = self.lstm(x)
        
        # Generate box coordinates
        box_pred = self.fc_layers(lstm_out)
        
        return box_pred


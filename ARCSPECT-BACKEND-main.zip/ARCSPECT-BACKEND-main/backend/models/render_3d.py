# models/render_3d.py

import os
from PIL import Image, ImageDraw

# Default room colors for easy visual distinction
ROOM_COLORS = {
    "bedroom": "lightblue",
    "kitchen": "orange",
    "bathroom": "skyblue",
    "washroom": "skyblue",
    "livingroom": "lightgreen",
    "balcony": "pink",
    "study": "plum",
    "default": "gray"
}

def scale_bbox(box, scale=10):
    """Scale bounding box coordinates (assumed to be 0–100) to pixels"""
    return [int(coord * scale) for coord in box]

def render_floor_plan(
    bounding_boxes: list,
    room_types: list = None,
    save_path: str = "static/outputs/generated.png",
    canvas_size: tuple = (600, 600)
):
    """
    Draws a 2D layout from predicted bounding boxes.

    Args:
        bounding_boxes (list): List of boxes [x1, y1, x2, y2]
        room_types (list): Optional list of room types per box
        save_path (str): Where to save the generated image
        canvas_size (tuple): Image resolution in pixels

    Returns:
        str: Full path to saved image
    """

    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    img = Image.new("RGB", canvas_size, "white")
    draw = ImageDraw.Draw(img)

    for idx, box in enumerate(bounding_boxes):
        scaled_box = scale_bbox(box)

        # Set fill color based on room type
        room_type = room_types[idx] if room_types and idx < len(room_types) else "default"
        fill_color = ROOM_COLORS.get(room_type, ROOM_COLORS["default"])

        draw.rectangle(scaled_box, outline="black", fill=fill_color, width=3)

        # Optionally label the room
        label_x = (scaled_box[0] + scaled_box[2]) // 2
        label_y = (scaled_box[1] + scaled_box[3]) // 2
        draw.text((label_x - 20, label_y - 10), room_type[:4].upper(), fill="black")

    img.save(save_path)
    return save_path

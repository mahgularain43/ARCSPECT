import torch
import torch.nn as nn
from transformers import BertModel, BertTokenizer

class TextEncoder(nn.Module):
    def __init__(self, embedding_dim=768):
        super(TextEncoder, self).__init__()
        self.bert = BertModel.from_pretrained('bert-base-uncased')
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        self.linear = nn.Linear(768, embedding_dim)  # BERT hidden size is 768
        
    def forward(self, text):
        # Tokenize and encode the text
        inputs = self.tokenizer(
            text,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=512
        )
        
        # Get BERT outputs
        outputs = self.bert(**inputs)
        
        # Use [CLS] token embedding
        text_embedding = outputs.last_hidden_state[:, 0, :]
        
        # Project to desired dimension
        text_embedding = self.linear(text_embedding)
        
        return text_embedding

def load_text_encoder(model_path=None):
    """
    Load or initialize the text encoder model
    """
    model = TextEncoder()
    
    if model_path and torch.cuda.is_available():
        model.load_state_dict(torch.load(model_path))
    elif model_path:
        model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
    
    return model


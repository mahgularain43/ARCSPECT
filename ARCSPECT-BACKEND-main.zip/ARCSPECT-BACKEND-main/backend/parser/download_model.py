from transformers import BertTokenizer, BertModel

print("⏳ Downloading BERT model and tokenizer...")
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
model = BertModel.from_pretrained("bert-base-uncased")
print("✅ Done!")


# evaluate_model.py
import torch
import json
import numpy as np
from pathlib import Path
from scene_graph_to_pyg import load_scene_graph_to_pyg
from gcn_layout_model import GCNLayoutPredictor

MODEL_PATH = Path("gcn_layout_model.pt")
GRAPH_DIR = Path("data/scene_graphs_enhanced_full")


def iou(boxA, boxB):
    ax1, ay1, aw, ah = boxA
    bx1, by1, bw, bh = boxB
    ax2, ay2 = ax1 + aw, ay1 + ah
    bx2, by2 = bx1 + bw, by1 + bh

    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0, ix2 - ix1), max(0, iy2 - iy1)
    inter = iw * ih
    union = aw * ah + bw * bh - inter
    return inter / union if union != 0 else 0


def evaluate():
    model = GCNLayoutPredictor(input_dim=7)
    model.load_state_dict(torch.load(MODEL_PATH))
    model.eval()

    total_iou, total_rmse, count = 0, 0, 0

    for graph_path in GRAPH_DIR.glob("*_graph.json"):
        data = load_scene_graph_to_pyg(graph_path)
        if data is None:
            print(f"[SKIP] Failed to load graph {graph_path.name}")
            continue

        print(f"[DEBUG] Loaded {data.num_nodes} nodes and {data.edge_index.shape[1]} edges from {graph_path.name}")

        if data.edge_index.shape[1] == 0:
            continue

        if data.x.shape[1] < 7:
            pad = torch.zeros((data.x.shape[0], 7 - data.x.shape[1]))
            data.x = torch.cat([data.x, pad], dim=1)

        with torch.no_grad():
            pred_y = model(data).numpy()
            true_y = data.y.numpy()

        for pred, true in zip(pred_y, true_y):
            total_iou += iou(pred, true)
            total_rmse += np.sqrt(((pred - true) ** 2).mean())
            count += 1

    if count == 0:
        print("No valid graphs with edges found for evaluation.")
        return

    print(f"\n📊 Evaluation over {count} room layouts:")
    print(f"Average IoU: {total_iou / count:.4f}")
    print(f"Average RMSE: {total_rmse / count:.4f}")


if __name__ == "__main__":
    evaluate()

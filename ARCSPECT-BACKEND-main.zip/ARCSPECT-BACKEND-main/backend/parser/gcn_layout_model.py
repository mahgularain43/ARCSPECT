import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import NNConv

class GCNLayoutPredictor(nn.Module):
    def __init__(self, node_input_dim=10, edge_attr_dim=2, hidden_dim=128, output_dim=4):
        super(GCNLayoutPredictor, self).__init__()

        self.nn_edge1 = nn.Sequential(
            nn.Linear(edge_attr_dim, hidden_dim * node_input_dim),
            nn.ReLU()
        )
        self.nn_edge2 = nn.Sequential(
            nn.Linear(edge_attr_dim, hidden_dim * hidden_dim),
            nn.ReLU()
        )

        self.conv1 = NNConv(node_input_dim, hidden_dim, self.nn_edge1, aggr='mean')
        self.conv2 = NNConv(hidden_dim, hidden_dim, self.nn_edge2, aggr='mean')

        self.pred_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim)  # 3 layers total
        )

        self.refine = nn.Sequential(
            nn.Linear(hidden_dim + output_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim)  # 3 layers total
        )

    def forward(self, data):
        x, edge_index, edge_attr = data.x, data.edge_index, data.edge_attr

        x = F.relu(self.conv1(x, edge_index, edge_attr))
        x = F.relu(self.conv2(x, edge_index, edge_attr))

        layout_init = self.pred_head(x)
        combined = torch.cat([layout_init, x], dim=1)
        layout_final = self.refine(combined)

        return layout_final


# parser/layout_generator.py

import torch
import torch.nn as nn
import torch.nn.functional as F

class GCNLayer(nn.Module):
    def __init__(self, in_features, out_features):
        super(GCNLayer, self).__init__()
        self.linear = nn.Linear(in_features, out_features)

    def forward(self, X, A):
        AX = torch.matmul(A, X)
        out = self.linear(AX)
        return F.relu(out)

class LayoutGCN(nn.Module):
    def __init__(self, input_dim=16, hidden_dim=64, output_dim=4):
        super(LayoutGCN, self).__init__()
        self.layer1 = GCNLayer(input_dim, hidden_dim)
        self.layer2 = GCNLayer(hidden_dim, output_dim)

    def forward(self, X, A):
        X = self.layer1(X, A)
        X = self.layer2(X, A)
        return X  # Returns bounding box coordinates (x, y, w, h) for each room

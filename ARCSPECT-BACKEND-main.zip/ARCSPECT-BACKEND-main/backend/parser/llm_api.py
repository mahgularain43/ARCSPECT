import os
import json
import re
import uuid
from dotenv import load_dotenv
from groq import Groq

load_dotenv()
client = Groq(api_key=os.getenv("GROQ_API_KEY"))

def extract_strict_json(text: str) -> dict | None:
    try:
        # Fix math expressions like 5**0.5 if any
        def safe_eval(match):
            try:
                return str(eval(match.group(0)))
            except:
                return "1"
        text = re.sub(r'\b\d+\s*\*\*\s*\d+(\.\d+)?\b', safe_eval, text)

        # Extract JSON from triple backticks
        json_block = re.search(r'```(?:json)?\s*({[\s\S]*?})\s*```', text)
        if json_block:
            text = json_block.group(1)
        else:
            # Fallback: extract from first `{`
            start_idx = text.find('{')
            if start_idx == -1:
                print("❌ Could not find JSON object in LLM output.")
                print("🔎 Raw Text:\n", text)
                return None
            text = text[start_idx:]

        # Remove trailing commas before closing braces/brackets
        text = re.sub(r',\s*(\}|\])', r'\1', text)

        # Fix missing closing quotes in connections (common LLM error)
        def fix_missing_quotes(text_inner):
            pattern = r'("\w+", )"(\w+)]'
            return re.sub(pattern, r'\1"\2"]', text_inner)
        text = fix_missing_quotes(text)

        # Balance brackets if needed
        def balance(s, open_c, close_c):
            diff = s.count(open_c) - s.count(close_c)
            if diff > 0:
                s += close_c * diff
            return s

        text = balance(text, '{', '}')
        text = balance(text, '[', ']')

        return json.loads(text.strip())

    except json.JSONDecodeError as e:
        print(f"❌ JSON decode error: {e}")
        print(f"🔎 Failing text:\n{text}")
    except Exception as e:
        print(f"❌ JSON extraction error: {e}")
        print(f"🔎 Raw fallback text:\n{text}")
    return None

def sanitize_room(room: dict, used_names: set) -> dict:
    try:
        base_name = str(room.get("name", f"room_{uuid.uuid4().hex[:4]}")).strip()
        name = base_name
        count = 1
        while name in used_names:
            name = f"{base_name}_{count}"
            count += 1
        used_names.add(name)
    except Exception:
        name = f"room_{uuid.uuid4().hex[:4]}"

    try:
        width = float(room.get("width", 2.0))
    except:
        width = 2.0
    try:
        height = float(room.get("height", 2.0))
    except:
        height = 2.0

    return {
        "name": name,
        "width": max(0.1, width),
        "height": max(0.1, height),
    }

def is_valid_room(room: dict) -> bool:
    return isinstance(room.get("name"), str) and room["name"].strip() != ""

def validate_architecture_input(text: str) -> bool:
    architecture_terms = ["room", "kitchen", "living room", "bedroom", "bathroom", "height", "width", "layout", "floorplan"]
    return any(term in text.lower() for term in architecture_terms)

def get_scene_graph_from_llm(prompt: str, retries=3) -> dict:
    system_prompt = """
You are a smart house planner AI. Your ONLY output must be a single valid JSON object enclosed in triple backticks (```), formatted exactly as follows:

{
  "rooms": [
    {
      "name": "room_name",
      "width": 0.25,
      "height": 0.2
    }
  ],
  "connections": [
    ["room_name1", "room_name2"]
  ]
}

Rules:
- Provide ONLY valid JSON, no explanations, no extra text.
- Always use double quotes for keys and string values.
- Rooms array must have one or more rooms, each with exactly "name" (string), "width" (number), and "height" (number).
- Connections array must have pairs of room names indicating adjacency.
- No trailing commas anywhere.
- If a field is missing, default width and height to 2.0.
- Respond with JSON only, wrapped inside triple backticks like ```json ... ```.

If your output is not valid JSON, you will be asked to retry.
"""

    for attempt in range(1, retries + 1):
        print(f"🔍 Requesting scene graph from LLM (attempt {attempt})...")

        # Validate prompt relevance
        if not validate_architecture_input(prompt):
            print("❌ Invalid input! Please provide a description related to architecture.")
            print("🔎 Suggestion: Try describing rooms like 'living room', 'kitchen', or 'bedroom' with their 'width' and 'height'.")
            return {"rooms": [], "connections": []}

        try:
            response = client.chat.completions.create(
                model="llama3-70b-8192",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.15,
                max_tokens=1024,
            )

            raw_output = response.choices[0].message.content.strip()
            print("🔎 Raw LLM Output:\n", raw_output)

            parsed = extract_strict_json(raw_output)
            if not parsed:
                raise ValueError("❌ Failed to parse JSON from LLM.")

            raw_rooms = parsed.get("rooms", [])
            used_names = set()
            valid_rooms = [sanitize_room(r, used_names) for r in raw_rooms if is_valid_room(r)]

            if not valid_rooms:
                raise ValueError("❌ No valid rooms found after sanitization.")

            raw_conns = parsed.get("connections", [])
            valid_room_names = {room["name"] for room in valid_rooms}
            valid_conns = [
                c for c in raw_conns
                if isinstance(c, list) and len(c) == 2 and
                   c[0] in valid_room_names and c[1] in valid_room_names
            ]

            scene_graph = {
                "rooms": valid_rooms,
                "connections": valid_conns,
            }
            print("✅ Final Scene Graph:\n", json.dumps(scene_graph, indent=2))
            return scene_graph

        except Exception as e:
            print(f"❌ Attempt {attempt} failed: {e}")
            if attempt == retries:
                print("❌ Max retries reached. Returning empty graph.")
                return {"rooms": [], "connections": []}

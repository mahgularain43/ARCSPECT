import os
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from skimage import io
from skimage.measure import find_contours
from shapely.geometry import Polygon

def load_mask_polygons_from_image(mask_path, min_area=50):
    """Load mask image and extract polygons from contours."""
    image = io.imread(mask_path)
    # Convert to grayscale if image has multiple channels
    if image.ndim == 3:
        image = image[..., 0]
    # Normalize and threshold
    binary_mask = image > 0
    contours = find_contours(binary_mask, level=0.5)
    polygons = []
    for contour in contours:
        poly = Polygon(contour)
        if poly.is_valid and poly.area >= min_area:
            polygons.append(poly)
    return polygons

def load_all_masks_polygons(masks_folder, max_files=None):
    """Load polygons from mask images in folder."""
    masks_folder = Path(masks_folder).resolve()
    print(f"Loading masks from: {masks_folder}")
    polygons = []
    files = sorted([f for f in masks_folder.iterdir() if f.suffix.lower() in ['.png', '.jpg', '.jpeg']])
    if max_files:
        files = files[:max_files]
    for f in files:
        try:
            mask_polys = load_mask_polygons_from_image(f)
            polygons.extend(mask_polys)
            print(f"Processed {f.name}, found {len(mask_polys)} polygons.")
        except Exception as e:
            print(f"Error processing {f.name}: {e}")
    print(f"Extracted {len(polygons)} polygons from {len(files)} mask images.")
    return polygons

if __name__ == "__main__":
    # Resolve masks folder relative to this script's location
    current_dir = Path(__file__).parent
    masks_folder = current_dir.parent / "data" / "mask_images"  # Adjust if your folder structure is different

    # Load polygons from first 5 mask images
    polygons = load_all_masks_polygons(masks_folder, max_files=5)

    # Plot polygons
    fig, ax = plt.subplots(figsize=(8, 8))
    for poly in polygons:
        x, y = poly.exterior.xy
        ax.plot(x, y, linewidth=2)
    ax.set_aspect('equal')
    ax.set_title("Polygons extracted from mask images")
    plt.show()

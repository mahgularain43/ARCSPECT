import os
import numpy as np
import matplotlib.pyplot as plt
from shapely.geometry import box, Polygon, LineString, MultiPolygon
from shapely.ops import unary_union
from shapely.validation import make_valid
from itertools import combinations # For pairwise checks in door detection

# ---------- Utility Functions ----------

def xywh_to_box(x, y, w, h):
    """Convert xywh normalized box to shapely box (minx, miny, maxx, maxy)."""
    # Assuming x, y are min_x, min_y for the box.
    # If your input x, y are center coordinates (e.g., from a detector), adjust like this:
    # return box(x - w/2, y - h/2, x + w/2, y + h/2)
    return box(x, y, x + w, y + h)

def load_predicted_boxes(file_path):
    """Load predicted boxes from numpy file and convert to shapely boxes."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Predicted boxes file not found: {file_path}")
    arr = np.load(file_path)
    print(f"Loaded {arr.shape} boxes from {file_path}")
    return [xywh_to_box(*b) for b in arr]

# ---------- Step (a) Remove duplicates ----------

def iou(box1, box2):
    """Calculate Intersection Over Union (IoU) of two boxes."""
    inter = box1.intersection(box2).area
    union = box1.union(box2).area
    return inter / union if union > 0 else 0

def remove_duplicates(boxes, iou_threshold=0.9):
    """
    Remove duplicate boxes based on IoU threshold.
    Higher threshold (e.g., 0.95): keeps more distinct boxes.
    Lower threshold (e.g., 0.7): removes more, potentially merging close boxes prematurely.
    """
    unique = []
    # Sort boxes by area to prioritize keeping larger ones if they overlap a lot
    boxes_sorted = sorted(boxes, key=lambda b: b.area, reverse=True)

    for b in boxes_sorted:
        is_duplicate = False
        for ub in unique:
            if iou(b, ub) > iou_threshold:
                is_duplicate = True
                break
        if not is_duplicate:
            unique.append(b)
    print(f"Removed duplicates: {len(boxes)} -> {len(unique)}")
    return unique

# ---------- Step (b) Snap edges ----------

def snap_edges(boxes, snap_tol=0.01):
    """
    Snap box edges to common grid lines.
    snap_tol: Maximum distance for an edge to snap to another.
    Larger snap_tol: more aggressive snapping, better for noisy predictions,
                    but might distort precise shapes.
    Smaller snap_tol: less snapping, preserves more original shapes,
                     but might leave slight misalignments.
    """
    vertical_coords = []
    horizontal_coords = []
    for b in boxes:
        minx, miny, maxx, maxy = b.bounds
        vertical_coords.extend([minx, maxx])
        horizontal_coords.extend([miny, maxy])
    
    # Use numpy.unique with a tolerance to find truly unique snap points
    vertical_snap_points = np.unique(np.array(vertical_coords).round(decimals=int(-np.log10(snap_tol)+2)))
    horizontal_snap_points = np.unique(np.array(horizontal_coords).round(decimals=int(-np.log10(snap_tol)+2)))

    # Ensure snap points are sorted
    vertical_snap_points = sorted(vertical_snap_points)
    horizontal_snap_points = sorted(horizontal_snap_points)


    def snap_coordinate(coord, snap_points, tolerance):
        # Find the closest snap point
        closest_snap = None
        min_dist = float('inf')
        for sp in snap_points:
            dist = abs(coord - sp)
            if dist < min_dist:
                min_dist = dist
                closest_snap = sp
        
        if closest_snap is not None and min_dist <= tolerance:
            return closest_snap
        return coord # No snap point found within tolerance

    snapped = []
    for b in boxes:
        minx, miny, maxx, maxy = b.bounds
        
        new_minx = snap_coordinate(minx, vertical_snap_points, snap_tol)
        new_maxx = snap_coordinate(maxx, vertical_snap_points, snap_tol)
        new_miny = snap_coordinate(miny, horizontal_snap_points, snap_tol)
        new_maxy = snap_coordinate(maxy, horizontal_snap_points, snap_tol)

        # Ensure valid box dimensions after snapping
        # Add a small buffer if dimensions collapse to zero, but ensure minx < maxx and miny < maxy
        if new_maxx <= new_minx:
            new_maxx = new_minx + 1e-6 # Ensure a minimum width
        if new_maxy <= new_miny:
            new_maxy = new_miny + 1e-6 # Ensure a minimum height
            
        snapped.append(box(new_minx, new_miny, new_maxx, new_maxy))
    print(f"Snapped edges on {len(boxes)} boxes.")
    return snapped

# ---------- Step (c) Refined Merge boxes (using grid and connected components) ----------

def merge_boxes_refined(boxes, grid_resolution=0.005, min_room_area=0.001):
    """
    Merges boxes into clean, orthogonal room polygons using a grid-based approach.
    grid_resolution: Size of the grid cells. Smaller value means finer detail but slower.
    min_room_area: Minimum area for a detected room polygon to be kept.
    """
    if not boxes:
        return []

    # 1. Determine overall bounding box of all predictions
    min_x = min(b.bounds[0] for b in boxes)
    min_y = min(b.bounds[1] for b in boxes)
    max_x = max(b.bounds[2] for b in boxes)
    max_y = max(b.bounds[3] for b in boxes)

    # Add a small buffer to the bounds
    buffer = grid_resolution * 2
    min_x -= buffer
    min_y -= buffer
    max_x += buffer
    max_y += buffer

    # 2. Create a grid
    grid_x = np.arange(min_x, max_x + grid_resolution, grid_resolution)
    grid_y = np.arange(min_y, max_y + grid_resolution, grid_resolution)

    grid_map = np.zeros((len(grid_y) - 1, len(grid_x) - 1), dtype=bool)

    # 3. Mark grid cells as occupied if they intersect any box
    for r in range(len(grid_y) - 1):
        for c in range(len(grid_x) - 1):
            cell_box = box(grid_x[c], grid_y[r], grid_x[c+1], grid_y[r+1])
            for b in boxes:
                if cell_box.intersects(b):
                    grid_map[r, c] = True
                    break

    # 4. Find connected components (rooms)
    from scipy.ndimage import label, generate_binary_structure
    s = generate_binary_structure(2, 1) # 4-connectivity
    labeled_array, num_features = label(grid_map, structure=s)

    room_polygons = []
    for i in range(1, num_features + 1):
        # Extract points for current component
        rows, cols = np.where(labeled_array == i)
        
        if len(rows) == 0: continue

        # Calculate min/max coordinates for this component
        comp_min_x = grid_x[cols.min()]
        comp_max_x = grid_x[cols.max() + 1]
        comp_min_y = grid_y[rows.min()]
        comp_max_y = grid_y[rows.max() + 1]
        
        # Create a rectangular polygon for the component
        room_poly = box(comp_min_x, comp_min_y, comp_max_x, comp_max_y)
        
        if room_poly.area > min_room_area:
            room_polygons.append(room_poly)
            
    print(f"Refined merging into {len(room_polygons)} orthogonal polygons.")
    return room_polygons

# ---------- Step (d) Find doors (shared boundaries) ----------

def find_doors(polygons, door_min_length=0.03, door_placement_ratio=0.5):
    """
    Find door segments on shared boundaries between polygons.
    Considers only axis-aligned shared segments for doors.
    """
    doors = []
    
    # Use combinations to check each unique pair of polygons
    for p1, p2 in combinations(polygons, 2):
        # Ensure polygons are valid before boundary intersection
        if not p1.is_valid or not p2.is_valid:
            continue

        inter = p1.boundary.intersection(p2.boundary)
        
        if inter.is_empty:
            continue
        
        segments_to_check = []
        if isinstance(inter, LineString):
            segments_to_check = [inter]
        elif isinstance(inter, MultiPolygon): # Unlikely for boundary intersection, but for robustness
            for geom in inter.geoms:
                if isinstance(geom, LineString):
                    segments_to_check.append(geom)
        elif hasattr(inter, 'geoms'): # Handles MultiLineString or GeometryCollection
            segments_to_check = [geom for geom in inter.geoms if isinstance(geom, LineString)]
        
        for geom_segment in segments_to_check:
            # Check if the segment is axis-aligned (horizontal or vertical)
            coords = geom_segment.coords
            if len(coords) < 2: continue
            
            is_horizontal = abs(coords[0][1] - coords[1][1]) < 1e-6 # Y-coordinates are nearly same
            is_vertical = abs(coords[0][0] - coords[1][0]) < 1e-6   # X-coordinates are nearly same

            if not (is_horizontal or is_vertical):
                continue # Skip non-axis-aligned shared boundaries

            if geom_segment.length > door_min_length:
                mid_point = geom_segment.interpolate(0.5, normalized=True)
                
                p_start = np.array(coords[0])
                p_end = np.array(coords[-1])
                
                direction_vector = p_end - p_start
                length = np.linalg.norm(direction_vector)
                
                if length == 0: continue

                unit_direction_vector = direction_vector / length
                
                door_actual_length = geom_segment.length * door_placement_ratio
                
                door_start_x = mid_point.x - (door_actual_length / 2) * unit_direction_vector[0]
                door_start_y = mid_point.y - (door_actual_length / 2) * unit_direction_vector[1]
                door_end_x = mid_point.x + (door_actual_length / 2) * unit_direction_vector[0]
                door_end_y = mid_point.y + (door_actual_length / 2) * unit_direction_vector[1]
                
                doors.append(LineString([(door_start_x, door_start_y), (door_end_x, door_end_y)]))
    
    print(f"Detected {len(doors)} door segments.")
    return doors

# ---------- Step (e) Plot and visualize ----------

def plot_floorplan(gt_boxes, merged_polygons=None, doors=None, title="Final Refined Floor Plan"):
    """Plots the refined floor plan components."""
    plt.figure(figsize=(10,10))
    ax = plt.gca()

    # Ground truth boxes (if provided) - shown for comparison
    if gt_boxes:
        ax.plot([], [], color="green", linewidth=3, label="GT (Green)") # Dummy plot for legend
        for i, b in enumerate(gt_boxes):
            if b.is_valid:
                x, y = b.exterior.xy
                ax.plot(x, y, color="green", linewidth=3, alpha=0.7, zorder=1)
                for interior in b.interiors:
                    x_int, y_int = interior.xy
                    ax.plot(x_int, y_int, color="green", linewidth=1.5, linestyle=':', alpha=0.7, zorder=1)

    # Merged polygons (the refined floor plan - these are the main rooms)
    if merged_polygons:
        ax.plot([], [], color="blue", linewidth=3, label="Merged (Blue)") # Dummy plot for legend
        for p in merged_polygons:
            if p.is_valid:
                x, y = p.exterior.xy
                ax.plot(x, y, color="blue", linewidth=3, zorder=2) # Main outline
                ax.fill(x, y, color='lightblue', alpha=0.3, zorder=1) # Fill interior

                # Plot interior rings (holes) if any
                for interior in p.interiors:
                    x_int, y_int = interior.xy
                    ax.plot(x_int, y_int, color="blue", linewidth=1.5, linestyle='--', alpha=0.7, zorder=2)
            else:
                print(f"Warning: Invalid merged polygon found, skipping plotting: {p}")

    # Doors - These are lines representing openings between rooms
    if doors:
        ax.plot([], [], color="black", linewidth=6, label="Door (Black)") # Dummy plot for legend
        for door in doors:
            x, y = door.xy
            ax.plot(x, y, color="black", linewidth=6, solid_capstyle='butt', zorder=3)

    ax.set_title(title)
    ax.set_aspect('equal', adjustable='box')
    ax.invert_yaxis() # Invert y-axis for typical image coordinates (top-left origin)

    # Adjust limits to fit all geometry nicely
    all_x = []
    all_y = []
    if gt_boxes:
        for b in gt_boxes: all_x.extend([b.bounds[0], b.bounds[2]]); all_y.extend([b.bounds[1], b.bounds[3]])
    if merged_polygons:
        for p in merged_polygons: all_x.extend([p.bounds[0], p.bounds[2]]); all_y.extend([p.bounds[1], p.bounds[3]])
    if doors:
        for d in doors: all_x.extend([d.bounds[0], d.bounds[2]]); all_y.extend([d.bounds[1], d.bounds[3]])
    
    if all_x and all_y:
        min_x, max_x = min(all_x), max(all_x)
        min_y, max_y = min(all_y), max(all_y)
        x_padding = (max_x - min_x) * 0.05
        y_padding = (max_y - min_y) * 0.05
        ax.set_xlim(min_x - x_padding, max_x + x_padding)
        ax.set_ylim(min_y - y_padding, max_y + y_padding)
    else: # Default limits if no geometry to plot
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)

    handles, labels = plt.gca().get_legend_handles_labels()
    unique_labels = {}
    for handle, label in zip(handles, labels):
        unique_labels[label] = handle
    ax.legend(unique_labels.values(), unique_labels.keys(), loc="upper right")

    plt.show()

# ---------- Main Pipeline ----------

def postprocess_floorplan(predicted_boxes_file, gt_boxes=None, 
                          iou_threshold=0.8, snap_tol=0.015, 
                          grid_resolution=0.005, min_room_area=0.001,
                          door_min_length=0.02, door_placement_ratio=0.4):
    """
    Main function to run the floor plan post-processing pipeline with refined merging.
    
    Args:
        predicted_boxes_file (str): Path to the .npy file containing predicted boxes.
        gt_boxes (list, optional): List of shapely box objects for ground truth. Defaults to None.
        iou_threshold (float): IoU threshold for removing duplicate predicted boxes.
        snap_tol (float): Tolerance for snapping box edges to common lines.
        grid_resolution (float): Size of grid cells for refined merging. Smaller is finer.
        min_room_area (float): Minimum area for a detected room polygon to be kept.
        door_min_length (float): Minimum length of a shared boundary to consider for a door.
        door_placement_ratio (float): Proportion of shared boundary length for door.
    
    Returns:
        tuple: (merged_polygons, doors)
    """
    print("--- Starting Floor Plan Post-Processing (Refined) ---")
    
    # Load predicted boxes
    pred_boxes = load_predicted_boxes(predicted_boxes_file)

    # Step (a): Remove duplicates
    unique_boxes = remove_duplicates(pred_boxes, iou_threshold=iou_threshold)

    # Step (b): Snap edges
    snapped_boxes = snap_edges(unique_boxes, snap_tol=snap_tol)

    # Step (c): Refined Merge boxes using grid and connected components
    merged_polys = merge_boxes_refined(snapped_boxes, grid_resolution=grid_resolution, 
                                       min_room_area=min_room_area)

    # Step (d): Find doors
    doors = find_doors(merged_polys, door_min_length=door_min_length, 
                       door_placement_ratio=door_placement_ratio)

    # Step (e): Plot final result - only plot merged polygons and doors for clean output
    plot_floorplan(gt_boxes, merged_polys, doors, title="Final Refined Floor Plan")

    print("--- Post-processing complete ---")
    return merged_polys, doors

# -------- Example Usage --------

if __name__ == "__main__":
    # --- Configuration Parameters ---
    # Adjust these values to fine-tune the refinement process for your data
    # These values are starting points; adjust based on your specific output
    MY_IOU_THRESHOLD = 0.8         # Lower this to remove more very close boxes early
    MY_SNAP_TOLERANCE = 0.015      # Crucial for orthogonal alignment
    MY_GRID_RESOLUTION = 0.005     # Finer grid (smaller value) captures more detail but slower
    MY_MIN_ROOM_AREA = 0.001       # Filter out very tiny merged artifacts
    MY_DOOR_MIN_LENGTH = 0.02      # Min length of a shared wall segment to be a door
    MY_DOOR_PLACEMENT_RATIO = 0.4  # How much of the shared wall the door occupies

    # --- Prepare Dummy Data (for demonstration if you don't have your own .npy) ---
    output_dir = "outputs/predicted_boxes"
    os.makedirs(output_dir, exist_ok=True)
    
    # This dummy data is designed to be challenging but should merge well with the
    # new grid-based approach. It attempts to create a layout similar to your GTs.
    dummy_pred_boxes = np.array([
        # Main L-shaped room / multiple boxes forming a larger area
        [0.25, 0.25, 0.45, 0.45], # Large central prediction
        [0.2, 0.3, 0.1, 0.2],    # Left part of L
        [0.4, 0.2, 0.2, 0.1],    # Bottom part of L
        [0.3, 0.5, 0.25, 0.15],   # Inner box, should be merged or define inner boundary
        
        # Right room / adjacent area
        [0.65, 0.2, 0.15, 0.3],   # Right vertical room
        [0.6, 0.45, 0.1, 0.08],   # Connector/small box
        
        # Top-right room / isolated box
        [0.7, 0.15, 0.1, 0.1],     # Top right isolated box
        
        # Some noise/smaller predictions
        [0.42, 0.43, 0.05, 0.05], # Small internal noise
        [0.55, 0.25, 0.05, 0.05]
    ])
    np.save(os.path.join(output_dir, "predicted_boxes_scene_0000.npy"), dummy_pred_boxes)
    print(f"Dummy predicted boxes saved to {os.path.join(output_dir, 'predicted_boxes_scene_0000.npy')}")

    predicted_file = os.path.join(output_dir, "predicted_boxes_scene_0000.npy")

    # --- Dummy Ground Truth (for comparison) ---
    # Create some dummy GT that somewhat resembles the expected clean output for the above predictions
    dummy_gt_boxes_data = np.array([
        [0.2, 0.2, 0.45, 0.5], # Main L-shape (simplified)
        [0.65, 0.2, 0.15, 0.3], # Right Room
        [0.7, 0.15, 0.1, 0.1]   # Top Right Room
    ])
    gt_boxes = [xywh_to_box(*b) for b in dummy_gt_boxes_data]
    print(f"Dummy ground truth boxes loaded.")

    # --- Run the Pipeline with Adjustable Parameters ---
    merged_polys, doors = postprocess_floorplan(
        predicted_file, 
        gt_boxes=gt_boxes,
        iou_threshold=MY_IOU_THRESHOLD,
        snap_tol=MY_SNAP_TOLERANCE,
        grid_resolution=MY_GRID_RESOLUTION,
        min_room_area=MY_MIN_ROOM_AREA,
        door_min_length=MY_DOOR_MIN_LENGTH,
        door_placement_ratio=MY_DOOR_PLACEMENT_RATIO
    )

    # Additional actions can be performed with merged_polys and doors here
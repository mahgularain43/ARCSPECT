import torch
import matplotlib.pyplot as plt
import json
from pathlib import Path
from scene_graph_to_pyg import load_scene_graph_to_pyg
from gcn_layout_model import GCNLayoutPredictor

# Path to graph and model
GRAPH_PATH = Path("data/scene_graphs_enhanced_full/00030_graph.json")
MODEL_PATH = Path("gcn_layout_model.pt")
EXPORT_PATH = Path("predicted_layout_00030.json")
SVG_EXPORT_PATH = Path("predicted_layout_00030.svg")

# Load graph
data = load_scene_graph_to_pyg(GRAPH_PATH)
if data is None:
    raise ValueError("Scene graph could not be loaded.")

# Ensure feature vector is compatible with trained model (7D)
if data.x.shape[1] < 7:
    pad_size = 7 - data.x.shape[1]
    pad = torch.zeros((data.x.shape[0], pad_size))
    data.x = torch.cat([data.x, pad], dim=1)

# Load model
model = GCNLayoutPredictor(input_dim=7)
model.load_state_dict(torch.load(MODEL_PATH))
model.eval()

# Predict
with torch.no_grad():
    pred_y = model(data).numpy()
    true_y = data.y.numpy()
    labels = data.room_labels

# Save predictions to JSON
layout = [
    {
        "id": labels[i],
        "x": float(x),
        "y": float(y),
        "width": float(w),
        "height": float(h)
    }
    for i, (x, y, w, h) in enumerate(pred_y)
]
with open(EXPORT_PATH, "w") as f:
    json.dump(layout, f, indent=2)

# Visualize
fig, ax = plt.subplots(figsize=(8, 6))

for i, (pred, true) in enumerate(zip(pred_y, true_y)):
    # Ground truth
    tx, ty, tw, th = true
    ax.add_patch(plt.Rectangle((tx, ty), tw, th, fill=False, edgecolor='green', linestyle='--', linewidth=1.5))
    ax.text(tx + tw/2, ty + th/2, labels[i], ha='center', va='center', fontsize=8, color='green')

    # Prediction
    px, py, pw, ph = pred
    ax.add_patch(plt.Rectangle((px, py), pw, ph, fill=False, edgecolor='red', linestyle='-', linewidth=1.5))
    ax.text(px + pw/2, py + ph/2, labels[i], ha='center', va='center', fontsize=8, color='red')

ax.set_xlim(0, 10)
ax.set_ylim(0, 10)
ax.set_aspect('equal')
ax.set_title("Predicted (red) vs. Ground Truth (green) Room Layout")
plt.grid(True)
plt.tight_layout()
plt.savefig(SVG_EXPORT_PATH, format='svg')
plt.show()

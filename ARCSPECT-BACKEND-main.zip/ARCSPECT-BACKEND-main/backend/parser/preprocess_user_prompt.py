import json
import re
import uuid
import networkx as nx
from typing import List, Dict, Tuple
from fuzzywuzzy import process
from backend.parser.llm_api import get_scene_graph_from_llm

# Accepted room types
ROOM_TYPES = ["bedroom", "bathroom", "washroom", "kitchen", "livingroom", "balcony", "study", "office", "garage", "diningroom"]

# One-hot encoded material maps
WALL_COLOR_MAP = {
    "white": 0, "granite": 1, "wood_color": 2, "gray": 3, "pink": 4,
    "orange": 5, "green": 6, "purple": 7, "default": 99
}

FLOOR_MATERIAL_MAP = {
    "wood": 0, "marble": 1, "ceramic": 2, "cement_board": 3,
    "jade": 4, "coating": 5, "default": 99
}

SCALE_FACTOR = 5.0  # Scale up width and height for room dimensions

# --- Utility Functions ---

def flatten_connections(connections: List) -> List[Tuple[str, str]]:
    edges = []
    for group in connections:
        if isinstance(group, list) and len(group) >= 2:
            for i in range(len(group) - 1):
                edges.append((group[i], group[i + 1]))
    return edges

def normalize_room_type(name: str) -> str:
    name = name.lower().replace(" ", "")
    match, score = process.extractOne(name, ROOM_TYPES)
    return match if score >= 70 else "unknown"

def assign_connected_layout(room_names: List[str], raw_connections: List[List[str]]) -> Dict[str, Tuple[float, float]]:
    G = nx.Graph()
    G.add_nodes_from(room_names)
    G.add_edges_from(flatten_connections(raw_connections))

    if len(G.nodes) == 0:
        return {}

    pos = nx.spring_layout(G, k=1.0, iterations=50, seed=42)
    spacing = 4.0
    layout = {node: (round(x * spacing, 3), round(y * spacing, 3)) for node, (x, y) in pos.items()}

    # Fill any missing nodes
    for i, r in enumerate(room_names):
        if r not in layout:
            layout[r] = ((i + 1) * spacing, -spacing)
    return layout

def encode_material(material_str: str, mapping: dict) -> List[int]:
    mats = [m.strip().lower().replace(" ", "_") for m in material_str.split(",")]
    vec = [0] * len(mapping)
    for m in mats:
        idx = mapping.get(m, mapping["default"])
        if idx != mapping["default"]:
            vec[idx] = 1
    return vec

# --- Main Entry ---

def parse_user_prompt(prompt: str) -> dict:
    print("🔍 Requesting scene graph from LLM...")

    # Ensure the prompt is architecture-related
    if not any(term in prompt.lower() for term in ["room", "kitchen", "livingroom", "bedroom", "bathroom"]):
        raise ValueError("❌ Invalid input. Please provide a description related to architectural rooms (e.g., 'kitchen', 'bedroom').")

    scene_raw = get_scene_graph_from_llm(prompt)

    if not scene_raw or not isinstance(scene_raw, dict):
        raise ValueError("❌ Invalid or no response from LLM.")

    raw_rooms = scene_raw.get("rooms", [])
    raw_connections = scene_raw.get("connections", [])

    if not raw_rooms or not isinstance(raw_rooms, list):
        raise ValueError("❌ Invalid or missing 'rooms' in LLM output.")

    room_names = [r.get("name", f"room_{i}") for i, r in enumerate(raw_rooms)]
    layout_positions = assign_connected_layout(room_names, raw_connections)

    used_names = set()
    nodes = []

    for i, room in enumerate(raw_rooms):
        base_name = room.get("name", f"room_{i}")
        name = base_name
        counter = 1
        while name in used_names:
            name = f"{base_name}_{counter}"
            counter += 1
        used_names.add(name)

        rtype = normalize_room_type(name)
        x, y = layout_positions.get(name, (0.0, 0.0))

        try:
            w = max(0.1, float(room.get("width", 2.0))) * SCALE_FACTOR
        except:
            w = 2.0 * SCALE_FACTOR
        try:
            h = max(0.1, float(room.get("height", 2.0))) * SCALE_FACTOR
        except:
            h = 2.0 * SCALE_FACTOR

        wall_color_str = room.get("wall", "default")
        floor_material_str = room.get("floor", "default")

        nodes.append({
            "id": i,
            "name": name,
            "type": rtype,
            "coordinates": {"x": x, "y": y},
            "dimensions": {"width": round(w, 3), "height": round(h, 3)},
            "area": round(w * h, 3),
            "wall_color": wall_color_str,
            "wall_color_encoded": encode_material(wall_color_str, WALL_COLOR_MAP),
            "floor_material": floor_material_str,
            "floor_material_encoded": encode_material(floor_material_str, FLOOR_MATERIAL_MAP),
        })

    name_to_idx = {node["name"]: node["id"] for node in nodes}
    edges = []
    for a, b in flatten_connections(raw_connections):
        if a in name_to_idx and b in name_to_idx:
            edges.append({
                "source": name_to_idx[a],
                "target": name_to_idx[b],
                "relation": "OC"
            })

    result = {
        "nodes": nodes,
        "edges": edges
    }

    print(f"✅ Parsed scene graph with {len(nodes)} nodes and {len(edges)} edges.")
    return result

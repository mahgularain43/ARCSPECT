import os
import json
import torch
from torch_geometric.data import Data
import math
from typing import List

# Room type to index mapping for one-hot encoding
room_type_to_idx = {
    "bedroom": 0,
    "bathroom": 1,
    "washroom": 2,
    "kitchen": 3,
    "livingroom": 4,
    "balcony": 5,
    "study": 6,
}
NUM_ROOM_TYPES = len(room_type_to_idx)

# Edge relation type mapping
edge_type_mapping = {
    "OC": 0,  # Open connection
    "C": 1,   # Closed or direct connection
}
DEFAULT_EDGE_TYPE = 2  # Unknown or default

def encode_room_type(name: str) -> List[int]:
    vec = [0] * NUM_ROOM_TYPES
    if not name:
        return vec
    name = name.lower()
    for key in room_type_to_idx:
        if key in name:
            vec[room_type_to_idx[key]] = 1
            break
    return vec

def load_scene_graph_txt(filepath: str) -> Data:
    """
    Load a single scene graph JSON file and convert it to PyTorch Geometric Data.
    Includes validation, clamping, and debug logging.
    """
    with open(filepath, 'r') as f:
        graph = json.load(f)

    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])

    node_feats = []
    node_targets = []
    room_centers = {}

    # Map room names (lowercase) to indices
    name_to_idx = {node.get("name", f"room{i}").lower(): i for i, node in enumerate(nodes)}
    max_idx = len(nodes) - 1

    for idx, node in enumerate(nodes):
        name = node.get("name", f"room{idx}")
        rtype = node.get("type", "unknown")
        coords = node.get("coordinates", {})
        dims = node.get("dimensions", {})

        # Parse and clamp x, y
        try:
            x_raw = coords.get("x", 0.5)
            x = float(x_raw)
        except Exception:
            print(f"⚠️ Node {idx} '{name}': invalid x coord '{coords.get('x')}', defaulting to 0.5")
            x = 0.5

        try:
            y_raw = coords.get("y", 0.5)
            y = float(y_raw)
        except Exception:
            print(f"⚠️ Node {idx} '{name}': invalid y coord '{coords.get('y')}', defaulting to 0.5")
            y = 0.5

        # Parse and clamp width and height
        try:
            w_raw = dims.get("width", 0.15)
            w = max(0.1, min(float(w_raw), 20.0))
            if float(w_raw) != w:
                print(f"⚠️ Node {idx} '{name}': width adjusted from {w_raw} to {w}")
        except Exception:
            print(f"⚠️ Node {idx} '{name}': invalid width '{dims.get('width')}', defaulting to 0.15")
            w = 0.15

        try:
            h_raw = dims.get("height", 0.15)
            h = max(0.1, min(float(h_raw), 20.0))
            if float(h_raw) != h:
                print(f"⚠️ Node {idx} '{name}': height adjusted from {h_raw} to {h}")
        except Exception:
            print(f"⚠️ Node {idx} '{name}': invalid height '{dims.get('height')}', defaulting to 0.15")
            h = 0.15

        area = w * h
        aspect_ratio = w / (h + 1e-6)

        one_hot = encode_room_type(rtype)
        dummy_feature = 0.0  # Placeholder if needed

        node_feats.append(one_hot + [area, aspect_ratio, dummy_feature])
        node_targets.append([x, y, w, h])
        room_centers[name.lower()] = (x, y)

    edge_index = []
    edge_attrs = []

    for edge in edges:
        src = edge.get("source")
        tgt = edge.get("target")

        # Convert string room names to indices if needed
        if isinstance(src, str):
            src = name_to_idx.get(src.lower())
        if isinstance(tgt, str):
            tgt = name_to_idx.get(tgt.lower())

        if src is None or tgt is None:
            print(f"⚠️ Skipping edge with invalid source/target: {edge}")
            continue

        if src < 0 or src > max_idx or tgt < 0 or tgt > max_idx:
            print(f"⚠️ Skipping edge with out-of-range indices: {edge}")
            continue

        rel = edge.get("relation", "OC")
        edge_type = edge_type_mapping.get(rel, DEFAULT_EDGE_TYPE)

        name1 = nodes[src].get("name", "").lower()
        name2 = nodes[tgt].get("name", "").lower()
        cx1, cy1 = room_centers.get(name1, (0.5, 0.5))
        cx2, cy2 = room_centers.get(name2, (0.5, 0.5))
        dist = math.sqrt((cx1 - cx2) ** 2 + (cy1 - cy2) ** 2)

        # Add both directions
        edge_index += [[src, tgt], [tgt, src]]
        edge_attrs += [[edge_type, dist], [edge_type, dist]]

    # Convert to tensors
    x = torch.tensor(node_feats, dtype=torch.float)
    y = torch.tensor(node_targets, dtype=torch.float)
    edge_index_tensor = torch.tensor(edge_index, dtype=torch.long).t().contiguous() if edge_index else torch.empty((2, 0), dtype=torch.long)
    edge_attr_tensor = torch.tensor(edge_attrs, dtype=torch.float) if edge_attrs else torch.empty((0, 2), dtype=torch.float)

    return Data(x=x, edge_index=edge_index_tensor, edge_attr=edge_attr_tensor, y=y)

import uuid
from datetime import datetime
from typing import Dict, Any, List

# Accepted room types
ROOM_TYPES = ["bedroom", "bathroom", "washroom", "kitchen", "livingroom", "balcony", "study", "office", "garage", "diningroom"]

def build_scene_graph(parsed_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build a structured scene graph from parsed LLM output, attaching metadata.

    Args:
        parsed_data (Dict[str, Any]): Dictionary containing 'nodes' and 'edges'.

    Returns:
        Dict[str, Any]: Structured graph with scene_id, timestamp, nodes, and edges.
    """
    scene_id = str(uuid.uuid4())[:8]
    timestamp = datetime.utcnow().isoformat() + "Z"

    nodes_raw: List[Dict[str, Any]] = parsed_data.get("nodes", [])
    edges_raw: List[Dict[str, Any]] = parsed_data.get("edges", [])

    nodes = []
    for i, node in enumerate(nodes_raw):
        coords = node.get("coordinates", {})
        dims = node.get("dimensions", {})

        # Handle x coordinate
        try:
            x_raw = coords.get("x", 0.5)
            x = float(x_raw)
        except (TypeError, ValueError):
            print(f"⚠️ Node {i}: Invalid x coordinate '{x_raw}', defaulting to 0.5")
            x = 0.5

        # Handle y coordinate
        try:
            y_raw = coords.get("y", 0.5)
            y = float(y_raw)
        except (TypeError, ValueError):
            print(f"⚠️ Node {i}: Invalid y coordinate '{y_raw}', defaulting to 0.5")
            y = 0.5

        # Handle width and height
        try:
            w_raw = dims.get("width", 0.15)
            width = max(0.1, min(float(w_raw), 20.0))
            if float(w_raw) != width:
                print(f"⚠️ Node {i}: Width adjusted from {w_raw} to {width}")
        except (TypeError, ValueError):
            print(f"⚠️ Node {i}: Invalid width '{dims.get('width')}', defaulting to 0.15")
            width = 0.15

        try:
            h_raw = dims.get("height", 0.15)
            height = max(0.1, min(float(h_raw), 20.0))
            if float(h_raw) != height:
                print(f"⚠️ Node {i}: Height adjusted from {h_raw} to {height}")
        except (TypeError, ValueError):
            print(f"⚠️ Node {i}: Invalid height '{dims.get('height')}', defaulting to 0.15")
            height = 0.15

        # Append node data
        nodes.append({
            "id": i,
            "name": node.get("name", f"room{i}"),
            "type": node.get("type", "unknown"),
            "coordinates": {"x": round(x, 3), "y": round(y, 3)},
            "dimensions": {"width": round(width, 3), "height": round(height, 3)},
            "area": round(width * height, 3),
        })

    # Handle edges
    edges = []
    for edge in edges_raw:
        try:
            src = int(edge.get("source"))
            tgt = int(edge.get("target"))
            rel = edge.get("relation", "OC")
            edges.append({
                "source": src,
                "target": tgt,
                "relation": rel
            })
        except (TypeError, ValueError):
            print(f"⚠️ Skipping invalid edge: {edge}")
            continue  # Skip invalid edges

    # Return the structured scene graph
    return {
        "scene_id": scene_id,
        "timestamp": timestamp,
        "nodes": nodes,
        "edges": edges
    }

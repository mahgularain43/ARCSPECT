# parser/text_to_graph_model.py

import torch
import torch.nn as nn
from transformers import BertModel

class TextToSceneGraphModel(nn.Module):
    def __init__(self, hidden_dim=256, num_node_classes=10, num_edge_classes=10):
        super().__init__()
        self.bert = BertModel.from_pretrained("bert-base-uncased")
        self.dropout = nn.Dropout(0.1)
        self.linear_node = nn.Linear(self.bert.config.hidden_size, num_node_classes)
        self.linear_edge = nn.Linear(self.bert.config.hidden_size, num_edge_classes)

    def forward(self, input_ids, attention_mask):
        output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        cls_output = output.last_hidden_state[:, 0]  # [CLS] token
        cls_output = self.dropout(cls_output)

        node_logits = self.linear_node(cls_output)
        edge_logits = self.linear_edge(cls_output)
        return node_logits, edge_logits

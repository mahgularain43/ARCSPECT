import torch
import torch.nn as nn
from transformers import BertTokenizer, BertModel

# ================================
# Model Definition
# ================================
class TextToSceneGraphModel(nn.Module):
    def __init__(self, hidden_dim=128, max_rooms=10, num_room_types=7, dropout=0.2):
        super().__init__()
        self.bert = BertModel.from_pretrained("bert-base-uncased")
        self.max_rooms = max_rooms
        self.num_room_types = num_room_types

        self.node_classifier = nn.Sequential(
            nn.Linear(self.bert.config.hidden_size, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_room_types)
        )

        self.edge_classifier = nn.Sequential(
            nn.Linear(self.bert.config.hidden_size * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, input_ids, attention_mask):
        B = input_ids.size(0)
        bert_output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        cls_embedding = bert_output.last_hidden_state[:, 0, :]  # (B, H)

        repeated = cls_embedding.unsqueeze(1).repeat(1, self.max_rooms, 1)  # (B, max_rooms, H)
        node_logits = self.node_classifier(repeated)  # (B, max_rooms, num_room_types)

        # Compute pairwise edge logits (symmetrized)
        edge_logits = torch.zeros(B, self.max_rooms, self.max_rooms).to(input_ids.device)
        for i in range(self.max_rooms):
            for j in range(i + 1, self.max_rooms):
                pair = torch.cat([repeated[:, i, :], repeated[:, j, :]], dim=1)
                logit = self.edge_classifier(pair).squeeze(-1)
                edge_logits[:, i, j] = logit
                edge_logits[:, j, i] = logit  # ensure symmetry

        # Mask diagonal (no self-loop edges)
        eye = torch.eye(self.max_rooms).unsqueeze(0).to(edge_logits.device)
        edge_logits = edge_logits.masked_fill(eye.bool(), -1e9)

        return node_logits, edge_logits

# ================================
# Training Setup
# ================================
def main():
    tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
    descriptions = [
        "Two bedrooms on the left and one washroom at the back",
        "Three bedrooms to the east and a living room in the middle"
    ]
    inputs = tokenizer(descriptions, return_tensors="pt", padding=True, truncation=True)

    # Model
    max_rooms = 10
    num_room_types = 7
    model = TextToSceneGraphModel(max_rooms=max_rooms, num_room_types=num_room_types)

    # Dummy ground truth
    B = inputs["input_ids"].size(0)
    true_node_labels = torch.randint(0, num_room_types, (B, max_rooms))
    true_edge_labels = torch.randint(0, 2, (B, max_rooms, max_rooms)).float()

    node_logits, edge_logits = model(inputs["input_ids"], inputs["attention_mask"])

    # === Losses ===
    node_loss_fn = nn.CrossEntropyLoss()
    edge_loss_fn = nn.BCEWithLogitsLoss()

    node_loss = node_loss_fn(node_logits.view(-1, num_room_types), true_node_labels.view(-1))

    # Ignore diagonal self-connections in edge loss
    mask = ~torch.eye(max_rooms).bool().unsqueeze(0).repeat(B, 1, 1).to(edge_logits.device)
    edge_loss = edge_loss_fn(edge_logits[mask], true_edge_labels[mask])

    total_loss = node_loss + edge_loss

    print("✅ Total Loss:", total_loss.item())

if __name__ == "__main__":
    main()

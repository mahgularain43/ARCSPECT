import json
import networkx as nx
import matplotlib.pyplot as plt
from pathlib import Path

def load_scene_graph(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        return json.load(f)

def visualize_scene_graph(scene_graph):
    G = nx.DiGraph()
    manual_positions = {}
    fallback_nodes = []

    # Add nodes and try to collect coordinates
    for node in scene_graph["nodes"]:
        G.add_node(node["id"], type=node["type"])
        if "coordinates" in node:
            manual_positions[node["id"]] = (
                node["coordinates"].get("x", 0),
                -node["coordinates"].get("y", 0)  # flip Y for better layout
            )
        else:
            fallback_nodes.append(node["id"])

    # Add edges with relation labels
    for edge in scene_graph["edges"]:
        G.add_edge(edge["source"], edge["target"], label=edge.get("relation", ""))

    # Fallback layout for nodes with no position
    fallback_layout = nx.spring_layout(G) if fallback_nodes else {}

    # Merge manual and fallback positions
    final_positions = {}
    for node in G.nodes():
        final_positions[node] = manual_positions.get(node, fallback_layout.get(node, (0, 0)))

    # Draw graph
    plt.figure(figsize=(14, 9))
    nx.draw_networkx_nodes(G, final_positions, node_color="skyblue", node_size=1000)
    nx.draw_networkx_edges(G, final_positions, edge_color="gray", arrows=True)
    nx.draw_networkx_labels(G, final_positions, font_size=9)

    edge_labels = {(u, v): d["label"] for u, v, d in G.edges(data=True)}
    nx.draw_networkx_edge_labels(G, final_positions, edge_labels=edge_labels, font_color="green", font_size=8)

    plt.title(f"Scene Graph Visualization – {scene_graph.get('scene_id', 'Unknown')}")
    plt.axis("off")
    plt.tight_layout()
    plt.show()

# ✅ This function will be used by FastAPI `/generate-design` endpoint to render a layout image
def render_layout(scene_graph: dict, save_path: str):
    fig, ax = plt.subplots(figsize=(6, 6))
    for node in scene_graph.get("nodes", []):
        x = node.get("coordinates", {}).get("x", 0)
        y = node.get("coordinates", {}).get("y", 0)
        width = node.get("dimensions", {}).get("width", 2)
        height = node.get("dimensions", {}).get("height", 2)
        room_type = node.get("type", "room")

        rect = plt.Rectangle((x, y), width, height, color="skyblue", edgecolor="black", linewidth=1.5)
        ax.add_patch(rect)
        ax.text(x + width/2, y + height/2, room_type, ha="center", va="center", fontsize=8)

    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.set_aspect('equal')
    ax.axis('off')
    plt.tight_layout()
    fig.savefig(save_path)
    plt.close(fig)

# 🧪 Manual test run
if __name__ == "__main__":
    GRAPH_PATH = Path("data/scene_graphs_enhanced_full/00003_graph.json")
    scene = load_scene_graph(GRAPH_PATH)
    visualize_scene_graph(scene)

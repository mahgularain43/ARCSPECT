import os
import json
import math
import networkx as nx
import torch
from shapely.geometry import box
from backend.parser.preprocess_user_prompt import parse_user_prompt
from backend.parser.scene_parser import build_scene_graph
from backend.parser.scene_graph_to_pyg import load_scene_graph_txt
from backend.parser.gcn_layout_model import GCNLayoutPredictor
from backend.postprocess_utils import (
    add_corridor_if_needed,
    export_floorplan_to_json,
    generate_svg_floorplan,
    grid_align_boxes,
    force_wall_alignment,
    remove_duplicates,
    resolve_overlaps,
    build_connection_graph,
    find_doors_with_semantic_links,
    generate_windows_for_exterior_walls,
)

import logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

def align_boxes_to_architectural_style(nodes, room_labels, edges, grid_gap=1.2):
    """Assign grid positions to all rooms, covering all connected components and isolated rooms."""

    G = nx.Graph()
    for i in range(len(nodes)):
        G.add_node(i)

    # Convert edges source/target to indices if needed
    name_to_idx = {node.get("name", f"room{i}").lower(): i for i, node in enumerate(nodes)}

    for edge in edges:
        src = edge.get("source")
        tgt = edge.get("target")
        if src == tgt:
            continue  # Skip self loops
        if isinstance(src, str):
            src = name_to_idx.get(src.lower())
        if isinstance(tgt, str):
            tgt = name_to_idx.get(tgt.lower())
        if src is None or tgt is None:
            continue
        G.add_edge(src, tgt)

    grid = {}
    idx_to_grid = {}
    occupied = set()
    visited = set()
    directions = [(1, 0), (0, 1), (-1, 0), (0, -1)]

    # BFS traversal over all connected components
    for component in nx.connected_components(G):
        queue = []
        start_node = next(iter(component))
        queue.append((start_node, 0, 0))
        while queue:
            node, gx, gy = queue.pop(0)
            if node in visited:
                continue
            grid[(gx, gy)] = node
            idx_to_grid[node] = (gx, gy)
            visited.add(node)
            for neighbor in G.neighbors(node):
                if neighbor not in visited:
                    for dx, dy in directions:
                        npos = (gx + dx, gy + dy)
                        if npos not in grid and npos not in occupied:
                            queue.append((neighbor, gx + dx, gy + dy))
                            occupied.add(npos)
                            break

    # Assign isolated nodes (not in any component) to free spots
    max_x = max((pos[0] for pos in idx_to_grid.values()), default=0)
    next_x = max_x + 1
    for i in range(len(nodes)):
        if i not in idx_to_grid:
            idx_to_grid[i] = (next_x, 0)
            next_x += 1

    # Create boxes with spacing
    ROOM_SIZES = {
        "livingroom": (4.0, 4.5), "hall": (3.2, 3.2),
        "bedroom": (3.5, 3.5), "kitchen": (2.5, 2.5),
        "bathroom": (2.0, 1.7), "study": (2.2, 1.8),
        "balcony": (1.6, 1.2), "terrace": (2.0, 1.8),
        "lawn": (3.0, 2.0), "closet": (1.2, 1.0),
        "diningroom": (3.0, 4.0), "dining room": (3.0, 4.0),
    }

    all_x = [pos[0] for pos in idx_to_grid.values()]
    all_y = [pos[1] for pos in idx_to_grid.values()]
    min_x, min_y = min(all_x), min(all_y)

    boxes = []
    for idx, (gx, gy) in idx_to_grid.items():
        label = room_labels[idx].lower()
        width, height = ROOM_SIZES.get(label, (2.6, 2.6))
        x = (gx - min_x) * (max(width, 2.4) + grid_gap)
        y = (gy - min_y) * (max(height, 2.2) + grid_gap)
        boxes.append(box(x, y, x + width, y + height))
    return boxes

def full_pipeline(user_input: str, scene_id: str) -> str:
    try:
        logger.info(f"🚀 Starting full pipeline for scene_id={scene_id}")

        # Step 1: Parse user input
        parsed = parse_user_prompt(user_input)
        logger.info("🔍 User prompt parsed.")

        # Step 2: Generate scene graph
        scene_graph = build_scene_graph(parsed)
        nodes = scene_graph.get("nodes", [])
        edges = scene_graph.get("edges", [])
        logger.info(f"✅ Scene graph: {len(nodes)} nodes, {len(edges)} edges.")

        if not nodes:
            raise ValueError("Scene graph contains no nodes.")

        # Step 3: Save raw semantic graph
        semantic_path = os.path.join("backend/data/semantic_expressions", f"{scene_id}.txt")
        os.makedirs(os.path.dirname(semantic_path), exist_ok=True)
        with open(semantic_path, 'w') as f:
            json.dump(scene_graph, f, indent=2)
        logger.info(f"📁 Scene graph saved at {semantic_path}")

        # Step 4: Load data and predict layout
        data = load_scene_graph_txt(semantic_path)
        model_path = "checkpoints/gcn_layout_model_spatial.pt"
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"🚫 Model not found at {model_path}")

        model = GCNLayoutPredictor(node_input_dim=10, edge_attr_dim=2, hidden_dim=128, output_dim=4)
        model.load_state_dict(torch.load(model_path, map_location="cpu"))
        model.eval()

        with torch.no_grad():
            pred_array = model(data).cpu().numpy()
        logger.info(f"🧠 Layout prediction complete. Predicted shape: {pred_array.shape}")

        # Step 5: Prepare room labels (use lowercased names)
        room_labels = [n.get("type", f"room_{i}").lower() for i, n in enumerate(nodes)]

        # Step 6: Layout with improved BFS and isolated node handling
        room_boxes = align_boxes_to_architectural_style(nodes, room_labels, edges, grid_gap=1.2)
        logger.info(f"Boxes after align_boxes_to_architectural_style: {len(room_boxes)}")

        # Step 7: Skip duplicates and overlap removal temporarily to preserve rooms
        refined_boxes = room_boxes

        # Validate boxes (same as before)
        validated_boxes = []
        for idx, b in enumerate(refined_boxes):
            minx, miny, maxx, maxy = b.bounds
            if any(math.isnan(v) for v in [minx, miny, maxx, maxy]):
                raise ValueError(f"❌ Invalid box geometry at index {idx}")
            width, height = maxx - minx, maxy - miny
            validated_boxes.append(box(minx, miny, minx + max(width, 0.5), miny + max(height, 0.5)))
        final_boxes = validated_boxes
        logger.info(f"Validated boxes count: {len(final_boxes)}")

        # Step 8: Structural features
        conn_graph = build_connection_graph(final_boxes, room_labels)
        semantic_links = edges if edges else []  # Use original edges
        doors = find_doors_with_semantic_links(conn_graph, room_labels, semantic_links)
        windows = generate_windows_for_exterior_walls(final_boxes)

        # Step 9: Output
        output_dir = os.path.join("backend/static/outputs", scene_id)
        os.makedirs(output_dir, exist_ok=True)

        json_path = os.path.join(output_dir, f"{scene_id}_layout.json")
        export_floorplan_to_json(final_boxes, room_labels, json_path)

        svg_path = os.path.join(output_dir, f"{scene_id}_floorplan.svg")

        generate_svg_floorplan(
            polygons=final_boxes,
            doors=doors,
            labels=room_labels,
            windows=windows,
            save_path=svg_path,
            wall_thickness=0.11,
            show_grid=False,
            edges=semantic_links
        )

        logger.info(f"🖼️ SVG exported: {svg_path}")
        return f"outputs/{scene_id}/{scene_id}_floorplan.svg"

    except Exception as e:
        logger.error(f"❌ Pipeline failed: {e}", exc_info=True)
        raise

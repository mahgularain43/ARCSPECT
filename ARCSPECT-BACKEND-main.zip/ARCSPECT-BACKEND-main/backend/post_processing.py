import json
import numpy as np
from shapely.geometry import box, LineString, Polygon
from shapely.ops import unary_union
import networkx as nx
import matplotlib.pyplot as plt

def iou(box1, box2):
    inter = box1.intersection(box2).area
    union = box1.union(box2).area
    return inter / union if union > 0 else 0

def remove_duplicates(boxes, iou_threshold=0.8):
    unique_boxes = []
    for b in boxes:
        if all(iou(b, ub) < iou_threshold for ub in unique_boxes):
            unique_boxes.append(b)
    return unique_boxes

def snap_boxes(boxes, snap_tol=0.01):
    vertical_edges, horizontal_edges = [], []
    for b in boxes:
        minx, miny, maxx, maxy = b.bounds
        vertical_edges.extend([minx, maxx])
        horizontal_edges.extend([miny, maxy])

    def snap_coord(coord, edges):
        for e in edges:
            if abs(coord - e) <= snap_tol:
                return e
        return coord

    snapped = []
    for b in boxes:
        minx, miny, maxx, maxy = b.bounds
        minx, maxx = snap_coord(minx, vertical_edges), snap_coord(maxx, vertical_edges)
        miny, maxy = snap_coord(miny, horizontal_edges), snap_coord(maxy, horizontal_edges)
        if minx >= maxx: maxx = minx + snap_tol
        if miny >= maxy: maxy = miny + snap_tol
        snapped.append(box(minx, miny, maxx, maxy))
    return snapped

def resolve_overlaps(boxes, iterations=200, move_step=0.002):
    for _ in range(iterations):
        overlaps = False
        new_boxes = []
        for i, b1 in enumerate(boxes):
            shift_x = shift_y = 0.0
            for j, b2 in enumerate(boxes):
                if i != j and b1.intersects(b2):
                    overlaps = True
                    dx = b1.centroid.x - b2.centroid.x
                    dy = b1.centroid.y - b2.centroid.y
                    shift_x += move_step if dx > 0 else -move_step
                    shift_y += move_step if dy > 0 else -move_step
            minx, miny, maxx, maxy = b1.bounds
            new_boxes.append(box(minx + shift_x, miny + shift_y, maxx + shift_x, maxy + shift_y))
        boxes = new_boxes
        if not overlaps: break
    return boxes

def normalize_boxes(boxes, norm_factor=500):
    return [box(b.bounds[0]/norm_factor, b.bounds[1]/norm_factor,
                b.bounds[2]/norm_factor, b.bounds[3]/norm_factor)
            for b in boxes]

def parse_semantic_expression_text(filepath):
    with open(filepath, 'r') as f:
        data = json.load(f)

    if "rooms" in data:
        rooms, labels = [], []
        for room_type, info in data['rooms'].items():
            for idx, bbox in enumerate(info['boundingbox']):
                minx = bbox['min']['x'] / 500
                miny = bbox['min']['y'] / 500
                maxx = bbox['max']['x'] / 500
                maxy = bbox['max']['y'] / 500
                rooms.append(box(minx, miny, maxx, maxy))
                name_list = info.get('name list', [])
                label = name_list[idx] if idx < len(name_list) else room_type
                labels.append(label.lower())
        links = data.get('links', [])
        return rooms, labels, links

    elif "nodes" in data:
        rooms, labels = [], []
        for node in data["nodes"]:
            x = node.get("coordinates", {}).get("x", 0)
            y = node.get("coordinates", {}).get("y", 0)
            w = node.get("dimensions", {}).get("width", 0.15)
            h = node.get("dimensions", {}).get("height", 0.15)
            rooms.append(box(x, y, x + w, y + h))
            labels.append(node.get("type", "unknown"))
        return rooms, labels, data.get("edges", [])

    else:
        raise ValueError("Unsupported file structure: missing 'rooms' or 'nodes' key")

def match_predicted_with_semantic(pred_boxes, semantic_rooms, semantic_labels, iou_thresh=0.1):
    matched = ['unknown'] * len(pred_boxes)
    for i, pb in enumerate(pred_boxes):
        best_iou, best_j = 0, -1
        for j, sb in enumerate(semantic_rooms):
            inter = pb.intersection(sb).area
            union = pb.union(sb).area
            iou_score = inter / union if union > 0 else 0
            if iou_score > best_iou:
                best_iou, best_j = iou_score, j
        if best_iou > iou_thresh:
            matched[i] = semantic_labels[best_j]
    return matched

def build_adjacency_graph(polygons, tol=1e-5):
    G = nx.Graph()
    for i, p1 in enumerate(polygons):
        G.add_node(i, polygon=p1)
        for j in range(i + 1, len(polygons)):
            p2 = polygons[j]
            inter = p1.boundary.intersection(p2.boundary)
            if not inter.is_empty and inter.length > tol:
                G.add_edge(i, j, shared_boundary=inter)
    return G

def find_doors_with_semantic_links(graph, room_labels, semantic_links, door_length_ratio=0.3, min_door_spacing=0.03):
    doors, door_positions = [], []
    label_to_nodes = {}
    for idx, label in enumerate(room_labels):
        label_to_nodes.setdefault(label, []).append(idx)
    for link in semantic_links:
        pair = link.get('room pair', [])
        if len(pair) != 2:
            continue
        a, b = pair[0].lower(), pair[1].lower()
        nodes_a, nodes_b = label_to_nodes.get(a, []), label_to_nodes.get(b, [])
        for u in nodes_a:
            for v in nodes_b:
                if graph.has_edge(u, v):
                    shared = graph[u][v].get('shared_boundary')
                    lines = [shared] if shared.geom_type == 'LineString' else list(shared.geoms)
                    for line in lines:
                        if line.length < 1e-5: continue
                        mid = line.interpolate(0.5, normalized=True)
                        if any(mid.distance(p) < min_door_spacing for p in door_positions):
                            continue
                        vx, vy = line.coords[-1][0] - line.coords[0][0], line.coords[-1][1] - line.coords[0][1]
                        mag = (vx ** 2 + vy ** 2) ** 0.5
                        vx, vy = vx / mag, vy / mag
                        door_len = line.length * door_length_ratio
                        dx0, dy0 = mid.x - (door_len / 2) * vx, mid.y - (door_len / 2) * vy
                        dx1, dy1 = mid.x + (door_len / 2) * vx, mid.y + (door_len / 2) * vy
                        doors.append(LineString([(dx0, dy0), (dx1, dy1)]))
                        door_positions.append(mid)
    return doors

def create_lawn(polygons, margin=0.02):
    union_poly = unary_union(polygons)
    minx, miny, maxx, maxy = union_poly.bounds
    return box(minx - margin, miny - margin, maxx + margin, maxy + margin).difference(union_poly)

def plot_floorplan_with_lawn(pred_boxes, merged_polygons, doors, room_labels, lawn, title, save_path):
    plt.figure(figsize=(10, 10))
    ax = plt.gca()

    if lawn:
        lawn_polys = [lawn] if lawn.geom_type == 'Polygon' else list(lawn.geoms)
        for lp in lawn_polys:
            x, y = lp.exterior.xy
            ax.fill(x, y, color='lightgreen', alpha=0.5, label='Lawn')

    for i, b in enumerate(pred_boxes):
        x, y = b.exterior.xy
        ax.plot(x, y, 'r--', linewidth=2, label='Predicted' if i == 0 else '')
        cx, cy = (b.bounds[0] + b.bounds[2]) / 2, (b.bounds[1] + b.bounds[3]) / 2
        ax.text(cx, cy, room_labels[i] if i < len(room_labels) else 'unknown',
                ha='center', va='center', fontsize=10, fontweight='bold', color='red')

    for i, p in enumerate(merged_polygons):
        x, y = p.exterior.xy
        ax.plot(x, y, 'b-', linewidth=2, label='Merged' if i == 0 else '')

    for i, d in enumerate(doors):
        x, y = d.xy
        ax.plot(x, y, 'k-', linewidth=4, label='Door' if i == 0 else '')

    ax.set_title(title)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.invert_yaxis()
    ax.set_aspect('equal')

    by_label = dict(zip(*ax.get_legend_handles_labels()))
    ax.legend(by_label.values(), by_label.keys())
    plt.savefig(save_path)
    plt.close()

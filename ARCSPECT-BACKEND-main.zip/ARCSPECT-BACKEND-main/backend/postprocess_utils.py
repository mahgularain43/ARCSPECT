import os
import json
import math
import networkx as nx
import svgwrite
import numpy as np
from shapely.geometry import box, LineString, Polygon
from shapely.affinity import translate
from shapely.ops import unary_union


# ----------- Room default sizes (meters) --------------
ROOM_SIZES = {
    "livingroom": (4.0, 4.5), "hall": (3.2, 3.2),
    "bedroom": (3.5, 3.5), "kitchen": (2.5, 2.5),
    "bathroom": (2.0, 1.7), "study": (2.2, 1.8),
    "balcony": (1.6, 1.2), "terrace": (2.0, 1.8),
    "lawn": (3.0, 2.0), "closet": (1.2, 1.0)
}

# --- Utilities (IOU, overlaps, snapping, etc) as before ---
def iou(box1, box2):
    inter = box1.intersection(box2).area
    union = box1.union(box2).area
    return inter / union if union > 0 else 0

def remove_duplicates(boxes, iou_threshold=0.8):
    return [b for i, b in enumerate(boxes)
            if all(iou(b, other) < iou_threshold for j, other in enumerate(boxes) if i != j)]

def resolve_overlaps(polygons, iterations=60, move_step=0.2):
    adjusted = polygons.copy()
    for _ in range(iterations):
        overlaps = False
        for i in range(len(adjusted)):
            for j in range(i + 1, len(adjusted)):
                if adjusted[i].intersects(adjusted[j]):
                    overlaps = True
                    c_i, c_j = adjusted[i].centroid, adjusted[j].centroid
                    dx, dy = c_i.x - c_j.x, c_i.y - c_j.y
                    length = math.hypot(dx, dy) or 1.0
                    shift_x, shift_y = move_step * (dx / length), move_step * (dy / length)
                    adjusted[j] = translate(adjusted[j], xoff=-shift_x, yoff=-shift_y)
        if not overlaps:
            break
    return adjusted

def grid_align_boxes(boxes, grid_step=0.05):
    snap = lambda val: round(val / grid_step) * grid_step
    return [box(snap(b.bounds[0]), snap(b.bounds[1]), snap(b.bounds[2]), snap(b.bounds[3])) for b in boxes]

def force_wall_alignment(boxes, tolerance=0.04):
    all_x, all_y = [], []
    for b in boxes:
        minx, miny, maxx, maxy = b.bounds
        all_x.extend([minx, maxx])
        all_y.extend([miny, maxy])
    def cluster(coords):
        coords = sorted(set(coords))
        groups = []
        while coords:
            base = coords.pop(0)
            group = []
            while coords and abs(coords[0] - base) <= tolerance:
                group.append(coords.pop(0))
            groups.append(round((sum(group) + base) / (len(group) + 1), 4))
        return groups
    snapped_x, snapped_y = cluster(all_x), cluster(all_y)
    snap = lambda val, group: min(group, key=lambda g: abs(val - g))
    return [box(snap(b.bounds[0], snapped_x), snap(b.bounds[1], snapped_y),
                snap(b.bounds[2], snapped_x), snap(b.bounds[3], snapped_y)) for b in boxes]

# ----------- Enhanced Grid Adjacency Layout -------------
def align_boxes_to_architectural_style(nodes, room_labels, edges, grid_gap=0.7):
    """Arrange rooms in a grid, placing connected rooms next to each other and leaving gaps for movement."""
    G = nx.Graph()
    for i, node in enumerate(nodes):
        G.add_node(i)
    for edge in edges:
        src = edge.get("source", edge[0] if isinstance(edge, (list, tuple)) else None)
        tgt = edge.get("target", edge[1] if isinstance(edge, (list, tuple)) else None)
        if src is not None and tgt is not None:
            if isinstance(src, str):
                src = next((i for i, n in enumerate(nodes) if n.get("name") == src or n.get("type") == src), None)
            if isinstance(tgt, str):
                tgt = next((i for i, n in enumerate(nodes) if n.get("name") == tgt or n.get("type") == tgt), None)
            if src is not None and tgt is not None:
                G.add_edge(src, tgt)

    # BFS traversal to assign rooms to a grid
    grid = {}
    visited = set()
    queue = [(0, 0, 0)]  # (node, x, y)
    directions = [(1, 0), (0, 1), (-1, 0), (0, -1)]
    idx_to_grid = {}
    occupied = set()
    while queue:
        node, gx, gy = queue.pop(0)
        if node in visited:
            continue
        grid[(gx, gy)] = node
        idx_to_grid[node] = (gx, gy)
        visited.add(node)
        for i, neighbor in enumerate(G.neighbors(node)):
            if neighbor not in visited:
                # Try all 4 directions for empty spot
                for dx, dy in directions:
                    npos = (gx + dx, gy + dy)
                    if npos not in grid and npos not in occupied:
                        queue.append((neighbor, gx + dx, gy + dy))
                        occupied.add(npos)
                        break

    # Center the grid
    all_x = [p[0] for p in idx_to_grid.values()]
    all_y = [p[1] for p in idx_to_grid.values()]
    min_x, min_y = min(all_x), min(all_y)
    # Place rooms on grid, leave gap between rooms
    boxes = []
    for idx, (gx, gy) in idx_to_grid.items():
        label = room_labels[idx].lower()
        width, height = ROOM_SIZES.get(label, (2.6, 2.6))
        x = (gx - min_x) * (max(width, 2.4) + grid_gap)
        y = (gy - min_y) * (max(height, 2.2) + grid_gap)
        boxes.append(box(x, y, x + width, y + height))
    return boxes

# --- Add corridor if needed ---
def add_corridor_if_needed(polygons, labels):
    # If many rooms, add a corridor in the middle (optional)
    if len(polygons) > 6:
        centers = np.array([ (p.centroid.x, p.centroid.y) for p in polygons ])
        mean = centers.mean(axis=0)
        corridor = box(mean[0]-2, mean[1]-1, mean[0]+2, mean[1]+1)
        polygons.append(corridor)
        labels.append("hall")
    return polygons, labels

# --- Room type auto-tag ---
def auto_tag_unknown_rooms(polygons, labels):
    updated = []
    for i, (poly, label) in enumerate(zip(polygons, labels)):
        area = poly.area * 10.7639  # m² to ft²
        if label.lower() in ["unknown", f"room_{i}"]:
            if area < 18: updated.append("closet")
            elif area < 40: updated.append("bathroom")
            elif area < 80: updated.append("study")
            elif area < 120: updated.append("bedroom")
            elif area < 200: updated.append("kitchen")
            else: updated.append("hall")
        else:
            updated.append(label)
    return updated

# --- Connection graph ---
def build_connection_graph(polygons, labels):
    G = nx.Graph()
    for i in range(len(polygons)):
        G.add_node(i, label=labels[i])
    for i in range(len(polygons)):
        for j in range(i + 1, len(polygons)):
            if polygons[i].touches(polygons[j]) or polygons[i].intersects(polygons[j]):
                G.add_edge(i, j)
    return G

def auto_infer_semantic_links(polygons):
    return [{"source": i, "target": j, "direction": "right"}
            for i in range(len(polygons)) for j in range(i+1, len(polygons)) if polygons[i].intersects(polygons[j])]

def find_doors_with_semantic_links(graph, labels, links):
    doors = []
    for link in links:
        src, tgt = link.get("source"), link.get("target")
        if graph.has_edge(src, tgt):
            shared = graph[src][tgt].get("shared_boundary", None)
            if shared and not shared.is_empty:
                line = shared if isinstance(shared, LineString) else list(shared.geoms)[0]
                mid = line.interpolate(0.5, normalized=True)
                vx, vy = line.coords[-1][0] - line.coords[0][0], line.coords[-1][1] - line.coords[0][1]
                mag = math.hypot(vx, vy)
                vx, vy = vx / mag, vy / mag
                len_half = 0.25 * line.length / 2
                dx0, dy0 = mid.x - vx * len_half, mid.y - vy * len_half
                dx1, dy1 = mid.x + vx * len_half, mid.y + vy * len_half
                doors.append(LineString([(dx0, dy0), (dx1, dy1)]))
    return doors


def generate_windows_for_exterior_walls(polygons):
    windows = []
    for poly in polygons:
        coords = list(poly.exterior.coords)
        for i in range(len(coords) - 1):
            edge = LineString([coords[i], coords[i+1]])
            if edge.length > 1.0:
                mid = edge.interpolate(0.5, normalized=True)
                vx, vy = coords[i+1][0] - coords[i][0], coords[i+1][1] - coords[i][1]
                mag = math.hypot(vx, vy)
                vx, vy = vx / mag, vy / mag
                len_half = 0.25 * edge.length / 2
                dx0, dy0 = mid.x - len_half * vx, mid.y - len_half * vy
                dx1, dy1 = mid.x + len_half * vx, mid.y + len_half * vy
                windows.append(LineString([(dx0, dy0), (dx1, dy1)]))
    return windows
# --- REMOVE ARROWS. Instead, draw '>' mark at each shared wall between rooms ---
# --- REMOVE ARROWS. Instead, draw '>' mark at each shared wall between rooms ---

def export_floorplan_to_json(boxes, labels, save_path):
    layout = []
    for i, b in enumerate(boxes):
        minx, miny, maxx, maxy = b.bounds
        material = "grass" if labels[i].lower() == "lawn" else "tile" if labels[i].lower() in ["kitchen", "bathroom"] else "wood"
        layout.append({
            "id": i,
            "label": labels[i],
            "x": float(minx),
            "y": float(miny),
            "width": float(maxx - minx),
            "height": float(maxy - miny),
            "material": material
        })
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, 'w') as f:
        json.dump(layout, f, indent=2)
from shapely.geometry import box, Polygon

def place_legend_dynamically(dwg, polygons, labels, width_px, height_px, margin, scale, offset_x, offset_y):
    legend_width = 170
    legend_height = len(labels) * 20 + 20

    # Convert all room polygons to SVG coordinates as shapely polygons
    room_polys_svg = []
    for poly in polygons:
        coords = [(x * scale + offset_x, height_px - (y * scale + offset_y)) for x, y in poly.exterior.coords]
        room_polys_svg.append(Polygon(coords))

    def get_legend_box(x, y):
        return box(x, y, x + legend_width, y + legend_height)

    def check_overlap(legend_poly):
        for room_poly in room_polys_svg:
            if legend_poly.intersects(room_poly):
                return True
        return False

    # Try positions: top-right, bottom-right, top-left
    candidate_positions = [
        (width_px - legend_width - margin, margin),                        # top-right
        (width_px - legend_width - margin, height_px - legend_height - margin), # bottom-right
        (margin, margin)                                                   # top-left
    ]

    legend_x, legend_y = None, None
    for (x, y) in candidate_positions:
        if not check_overlap(get_legend_box(x, y)):
            legend_x, legend_y = x, y
            break

    # If all positions overlap, default to top-right
    if legend_x is None or legend_y is None:
        legend_x, legend_y = candidate_positions[0]

    # Add legend group to SVG
    legend_group = dwg.g(id="legend")
    legend_group.add(dwg.rect(
        insert=(legend_x - 8, legend_y - 12),
        size=(legend_width, legend_height),
        fill='white',
        fill_opacity=0.95,
        stroke='#666',
        stroke_width=1.2,
        rx=5,
        ry=5
    ))

    for i, label in enumerate(labels):
        legend_group.add(dwg.text(
            f"{i + 1}. {label.title()}",
            insert=(legend_x, legend_y + 20 * (i + 1)),
            font_size=13,
            fill="#000",
            font_family='Arial'
        ))

    dwg.add(legend_group)
# --- SVG generator (now with bolder walls & clearer text) ---
import svgwrite
import math
from shapely.geometry import MultiPolygon

def generate_svg_floorplan(
    polygons,
    doors,
    labels,
    save_path,
    scale=None,
    margin_ratio=0.05,
    windows=None,
    wall_thickness=0.15,
    show_grid=False,
    edges=None
):
    import math
    from shapely.ops import unary_union
    from shapely.geometry import Polygon, MultiPolygon

    fill_colors = {
        "bedroom": "#cde7ff", "kitchen": "#ffd9d9", "livingroom": "#d9ffd9",
        "bathroom": "#fff3cd", "washroom": "#f0e6ff", "balcony": "#d9f0ff",
        "study": "#ffe6cc", "garage": "#e6e6e6", "hall": "#e6f7ff",
        "terrace": "#fffbe6", "lawn": "#f6ffed", "unknown": "#f5f5f5"
    }

    all_x, all_y = [], []
    for poly in polygons:
        xs, ys = poly.exterior.xy
        all_x.extend(xs)
        all_y.extend(ys)

    layout_width = max(all_x) - min(all_x)
    layout_height = max(all_y) - min(all_y)
    max_dim = max(layout_width, layout_height)
    scale = scale or (1000 / max_dim if max_dim > 0 else 100)
    margin = max_dim * margin_ratio * scale
    width_px = layout_width * scale + 2 * margin
    height_px = layout_height * scale + 2 * margin
    offset_x = -min(all_x) * scale + margin
    offset_y = -min(all_y) * scale + margin

    dwg = svgwrite.Drawing(save_path, size=(width_px, height_px), profile='full')
    dwg.add(dwg.rect(insert=(0, 0), size=(width_px, height_px), fill='white'))

    # Define hatch pattern for overlaps
    pattern = dwg.defs.add(dwg.pattern(id="hatchPattern", size=(6,6), patternUnits="userSpaceOnUse", patternTransform="rotate(45)"))
    pattern.add(dwg.line((0,0), (0,6), stroke="#666666", stroke_width=1))
    pattern.add(dwg.line((3,0), (3,6), stroke="#666666", stroke_width=1))

    def to_svg_coords(geom):
        return [(x * scale + offset_x, height_px - (y * scale + offset_y)) for x, y in geom.exterior.coords]

    # Draw rooms with fill color ONLY, no stroke (no borders)
    centroids = []
    for idx, (poly, label) in enumerate(zip(polygons, labels)):
        fill_color = fill_colors.get(label.lower(), fill_colors["unknown"])
        if poly.is_valid:
            dwg.add(dwg.polygon(
                to_svg_coords(poly),
                fill=fill_color,
                stroke="none",
                fill_opacity=0.9
            ))

        # Room label & area
        c = poly.centroid
        cx, cy = c.x * scale + offset_x, height_px - (c.y * scale + offset_y)
        centroids.append((cx, cy))
        area = round(poly.area * 10.7639, 2)

        dwg.add(dwg.text(
            f"{label.upper()}",
            insert=(cx, cy - 8),
            text_anchor='middle',
            font_size=16,
            fill='#000000',
            font_weight='bold',
            font_family='Arial'
        ))
        dwg.add(dwg.text(
            f"{area} ft²",
            insert=(cx, cy + 10),
            text_anchor='middle',
            font_size=12,
            fill="#000000",
            font_family='Arial'
        ))

    # Draw hatch fill for overlapping/walking areas between rooms
    for i in range(len(polygons)):
        for j in range(i + 1, len(polygons)):
            if polygons[i].touches(polygons[j]) or polygons[i].intersects(polygons[j]):
                inter = polygons[i].intersection(polygons[j])
                if not inter.is_empty and inter.is_valid:
                    if inter.geom_type == 'Polygon':
                        dwg.add(dwg.polygon(
                            to_svg_coords(inter),
                            fill="url(#hatchPattern)",
                            stroke="none",
                            fill_opacity=0.5
                        ))
                    elif inter.geom_type == 'MultiPolygon':
                        for poly in inter.geoms:
                            dwg.add(dwg.polygon(
                                to_svg_coords(poly),
                                fill="url(#hatchPattern)",
                                stroke="none",
                                fill_opacity=0.5
                            ))

    # Draw outer boundary around entire floor plan
    union_poly = unary_union(polygons)
    if union_poly.is_valid:
        if union_poly.geom_type == 'Polygon':
            outline_coords = [(x * scale + offset_x, height_px - (y * scale + offset_y)) for x, y in union_poly.exterior.coords]
            dwg.add(dwg.polygon(
                outline_coords,
                fill='none',
                stroke='#000000',
                stroke_width=3
            ))
        elif union_poly.geom_type == 'MultiPolygon':
            for poly in union_poly.geoms:
                outline_coords = [(x * scale + offset_x, height_px - (y * scale + offset_y)) for x, y in poly.exterior.coords]
                dwg.add(dwg.polygon(
                    outline_coords,
                    fill='none',
                    stroke='#000000',
                    stroke_width=3
                ))

    # Calculate open space areas dynamically by subtracting union of rooms from bounding box
    bounding_box = union_poly.envelope  # Minimal bounding rectangle around union
    open_space = bounding_box.difference(union_poly)

    def draw_open_space(poly):
        if poly.is_empty or not poly.is_valid:
            return
        if poly.geom_type == 'Polygon':
            coords = to_svg_coords(poly)
            dwg.add(dwg.polygon(
                coords,
                fill='none',
                stroke='#ff6600',
                stroke_width=2,
                stroke_dasharray="8,8",
                fill_opacity=0.0
            ))
            # Place "Open Space" label near centroid
            c = poly.centroid
            cx, cy = c.x * scale + offset_x, height_px - (c.y * scale + offset_y)
            dwg.add(dwg.text(
                "Open Space",
                insert=(cx, cy),
                text_anchor='middle',
                font_size=16,
                fill='#ff6600',
                font_weight='bold',
                font_family='Arial'
            ))
        elif poly.geom_type == 'MultiPolygon':
            for p in poly.geoms:
                draw_open_space(p)

    draw_open_space(open_space)

    # Draw semantic connection dotted lines (unchanged)
    if edges:
        for edge in edges:
            src = edge.get("source")
            tgt = edge.get("target")
            if src is None or tgt is None:
                continue
            if src >= len(centroids) or tgt >= len(centroids):
                continue
            cx1, cy1 = centroids[src]
            cx2, cy2 = centroids[tgt]

            dwg.add(dwg.line(
                start=(cx1, cy1), end=(cx2, cy2),
                stroke="#888888", stroke_dasharray="4,4", stroke_width=1.2
            ))

            mx, my = (cx1 + cx2) / 2, (cy1 + cy2) / 2
            angle = math.degrees(math.atan2(cy2 - cy1, cx2 - cx1))
            dwg.add(dwg.text(
                ">", insert=(mx, my),
                transform=f"rotate({angle} {mx} {my})",
                text_anchor="middle", font_size=14,
                fill="#444", font_family='Arial'
            ))
        place_legend_dynamically(dwg, polygons, labels, width_px, height_px, margin, scale, offset_x, offset_y)


 
    dwg.save()
    print(f"✅ generate_svg_floorplan(): SVG saved to {save_path}")

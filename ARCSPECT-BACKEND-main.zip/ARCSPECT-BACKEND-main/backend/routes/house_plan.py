from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from typing import Dict
from pydantic import BaseModel
from ..parser.scene_graph import SceneGraphParser
from ..generator.layout_generator import LayoutGenerator
from ..models import HousePlan, Room
from ..db import get_db

router = APIRouter()
scene_graph_parser = SceneGraphParser()
layout_generator = LayoutGenerator()

class HousePlanRequest(BaseModel):
    description: str

class HousePlanResponse(BaseModel):
    id: int
    description: str
    scene_graph: Dict
    layout_data: Dict
    layout_image_url: str

@router.post("/generate", response_model=HousePlanResponse)
async def generate_house_plan(
    request: HousePlanRequest,
    db: Session = Depends(get_db)
):
    try:
        # 1. Parse text to scene graph
        scene_graph = scene_graph_parser.parse_text(request.description)
        
        # 2. Generate layout
        layout_image_path, layout_data = layout_generator.generate_basic_layout(scene_graph)
        
        # 3. Create house plan entry
        house_plan = HousePlan(
            description=request.description,
            scene_graph=scene_graph,
            layout_data=layout_data,
        )
        
        # 4. Create room entries
        rooms = []
        for room_name, room_data in layout_data.items():
            x, y, width, height = room_data['bbox']
            room = Room(
                room_type=room_name,
                area=room_data['area'],
                position_x=x,
                position_y=y,
                house_plan=house_plan
            )
            rooms.append(room)
        
        # 5. Save to database
        db.add(house_plan)
        db.add_all(rooms)
        db.commit()
        db.refresh(house_plan)
        
        # 6. Return response
        return {
            "id": house_plan.id,
            "description": house_plan.description,
            "scene_graph": house_plan.scene_graph,
            "layout_data": house_plan.layout_data,
            "layout_image_url": f"/static/{layout_image_path}"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) 
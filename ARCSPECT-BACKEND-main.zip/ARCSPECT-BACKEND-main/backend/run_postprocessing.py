import json
import numpy as np
import os
from shapely.geometry import box, LineString, Polygon
from shapely.ops import unary_union
import networkx as nx
import matplotlib.pyplot as plt

def iou(box1, box2):
    inter = box1.intersection(box2).area
    union = box1.union(box2).area
    return inter / union if union > 0 else 0

def remove_duplicates(boxes, iou_threshold=0.8):
    unique_boxes = []
    for b in boxes:
        if all(iou(b, ub) < iou_threshold for ub in unique_boxes):
            unique_boxes.append(b)
    return unique_boxes

def snap_boxes(boxes, snap_tol=0.01):
    vertical_edges = []
    horizontal_edges = []
    for b in boxes:
        minx, miny, maxx, maxy = b.bounds
        vertical_edges.extend([minx, maxx])
        horizontal_edges.extend([miny, maxy])

    def snap_coord(coord, edges):
        for e in edges:
            if abs(coord - e) <= snap_tol:
                return e
        return coord

    snapped_boxes = []
    for b in boxes:
        minx, miny, maxx, maxy = b.bounds
        minx = snap_coord(minx, vertical_edges)
        maxx = snap_coord(maxx, vertical_edges)
        miny = snap_coord(miny, horizontal_edges)
        maxy = snap_coord(maxy, horizontal_edges)

        if minx >= maxx:
            maxx = minx + snap_tol
        if miny >= maxy:
            maxy = miny + snap_tol

        snapped_boxes.append(box(minx, miny, maxx, maxy))

    return snapped_boxes

def resolve_overlaps(boxes, iterations=200, move_step=0.002):
    for _ in range(iterations):
        overlaps = False
        new_boxes = []
        for i, b1 in enumerate(boxes):
            shift_x, shift_y = 0.0, 0.0
            for j, b2 in enumerate(boxes):
                if i == j:
                    continue
                if b1.intersects(b2):
                    overlaps = True
                    dx = (b1.centroid.x - b2.centroid.x)
                    dy = (b1.centroid.y - b2.centroid.y)
                    if abs(dx) > abs(dy):
                        shift_x += move_step if dx > 0 else -move_step
                    else:
                        shift_y += move_step if dy > 0 else -move_step
            minx, miny, maxx, maxy = b1.bounds
            shifted_box = box(minx + shift_x, miny + shift_y, maxx + shift_x, maxy + shift_y)
            new_boxes.append(shifted_box)
        boxes = new_boxes
        if not overlaps:
            break
    return boxes

def normalize_boxes(boxes, norm_factor=500):
    normalized = []
    for b in boxes:
        minx, miny, maxx, maxy = b.bounds
        norm_box = box(minx / norm_factor, miny / norm_factor, maxx / norm_factor, maxy / norm_factor)
        normalized.append(norm_box)
    return normalized

def parse_semantic_expression_text(filepath):
    with open(filepath, 'r') as f:
        data = json.load(f)
    rooms = []
    labels = []
    for room_type, info in data['rooms'].items():
        for idx, bbox in enumerate(info['boundingbox']):
            minx = bbox['min']['x'] / 500
            miny = bbox['min']['y'] / 500
            maxx = bbox['max']['x'] / 500
            maxy = bbox['max']['y'] / 500
            rooms.append(box(minx, miny, maxx, maxy))
            name_list = info.get('name list', [])
            label = name_list[idx] if idx < len(name_list) else room_type
            labels.append(label.lower())
    links = data.get('links', [])
    return rooms, labels, links

def convert_pred_to_shapely(pred_array):
    shapely_boxes = []
    for x, y, w, h in pred_array:
        shapely_boxes.append(box(x, y, x + w, y + h))
    return shapely_boxes

def match_predicted_with_semantic(pred_boxes, semantic_rooms, semantic_labels, iou_thresh=0.1):
    matched_labels = ['unknown'] * len(pred_boxes)
    for i, pred_box in enumerate(pred_boxes):
        best_iou = 0
        best_j = -1
        for j, sem_box in enumerate(semantic_rooms):
            inter = pred_box.intersection(sem_box).area
            union = pred_box.union(sem_box).area
            iou_score = inter / union if union > 0 else 0
            if iou_score > best_iou:
                best_iou = iou_score
                best_j = j
        if best_iou > iou_thresh:
            matched_labels[i] = semantic_labels[best_j]
    return matched_labels

def build_adjacency_graph(polygons, tol=1e-5):
    G = nx.Graph()
    for i, p1 in enumerate(polygons):
        G.add_node(i, polygon=p1)
    for i, p1 in enumerate(polygons):
        for j in range(i + 1, len(polygons)):
            p2 = polygons[j]
            inter = p1.boundary.intersection(p2.boundary)
            if not inter.is_empty and (inter.length > tol):
                G.add_edge(i, j, shared_boundary=inter)
    return G

def find_doors_with_semantic_links(graph, room_labels, semantic_links, door_length_ratio=0.3, min_door_spacing=0.03):
    doors = []
    door_positions = []
    label_to_nodes = {}
    for idx, label in enumerate(room_labels):
        label_to_nodes.setdefault(label, []).append(idx)
    for link in semantic_links:
        pair = link.get('room pair', [])
        if len(pair) != 2:
            continue
        label_a, label_b = pair[0].lower(), pair[1].lower()
        nodes_a = label_to_nodes.get(label_a, [])
        nodes_b = label_to_nodes.get(label_b, [])
        for u in nodes_a:
            for v in nodes_b:
                if graph.has_edge(u, v):
                    shared = graph[u][v].get('shared_boundary')
                    if shared is None:
                        continue
                    line_segs = [shared] if shared.geom_type == 'LineString' else list(shared.geoms)
                    for line in line_segs:
                        length = line.length
                        if length < 1e-5:
                            continue
                        mid = line.interpolate(0.5, normalized=True)
                        if any(mid.distance(p) < min_door_spacing for p in door_positions):
                            continue
                        vx = line.coords[-1][0] - line.coords[0][0]
                        vy = line.coords[-1][1] - line.coords[0][1]
                        mag = (vx ** 2 + vy ** 2) ** 0.5
                        vx /= mag
                        vy /= mag
                        door_len = length * door_length_ratio
                        dx0 = mid.x - (door_len / 2) * vx
                        dy0 = mid.y - (door_len / 2) * vy
                        dx1 = mid.x + (door_len / 2) * vx
                        dy1 = mid.y + (door_len / 2) * vy
                        door_line = LineString([(dx0, dy0), (dx1, dy1)])
                        doors.append(door_line)
                        door_positions.append(mid)
    return doors

def create_lawn(polygons, margin=0.02):
    union_poly = unary_union(polygons)
    minx, miny, maxx, maxy = union_poly.bounds
    lawn_rect = box(minx - margin, miny - margin, maxx + margin, maxy + margin)
    lawn = lawn_rect.difference(union_poly)
    return lawn

def plot_floorplan_with_lawn(pred_boxes, merged_polygons, doors, room_labels, lawn, title, save_path):
    plt.figure(figsize=(10, 10))
    ax = plt.gca()

    # Plot lawn
    if lawn:
        if lawn.geom_type == 'Polygon':
            xs, ys = lawn.exterior.xy
            ax.fill(xs, ys, color='lightgreen', alpha=0.5, label='Lawn')
        elif lawn.geom_type == 'MultiPolygon':
            for poly in lawn.geoms:
                xs, ys = poly.exterior.xy
                ax.fill(xs, ys, color='lightgreen', alpha=0.5, label='Lawn')

    # Plot predicted boxes & labels
    for i, b in enumerate(pred_boxes):
        x, y = b.exterior.xy
        ax.plot(x, y, 'r--', linewidth=2, label='Predicted' if i == 0 else "")
        cx = (b.bounds[0] + b.bounds[2]) / 2
        cy = (b.bounds[1] + b.bounds[3]) / 2
        label = room_labels[i] if i < len(room_labels) else 'unknown'
        ax.text(cx, cy, label, ha='center', va='center', fontsize=10, fontweight='bold', color='red')

    # Plot merged polygons
    for i, p in enumerate(merged_polygons):
        x, y = p.exterior.xy
        ax.plot(x, y, 'b-', linewidth=2, label='Merged' if i == 0 else "")

    # Plot doors
    for i, door in enumerate(doors):
        x, y = door.xy
        ax.plot(x, y, 'k-', linewidth=4, label='Door' if i == 0 else "")

    ax.set_title(title)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.invert_yaxis()
    ax.set_aspect('equal')

    handles, labels = ax.get_legend_handles_labels()
    by_label = dict(zip(labels, handles))
    ax.legend(by_label.values(), by_label.keys())

    plt.savefig(save_path)
    plt.close()


if __name__ == "__main__":
    os.makedirs("floorplan_images", exist_ok=True)

    scene_id = 0
    semantic_file = f"backend/data/semantic_expression/{scene_id:05d}.txt"
    predicted_npy = f"outputs/predicted_boxes/predicted_boxes_scene_{scene_id:04d}.npy"

    semantic_rooms, semantic_labels, semantic_links = parse_semantic_expression_text(semantic_file)

    pred_array = np.load(predicted_npy)
    predicted_boxes = convert_pred_to_shapely(pred_array)

    # 1. Remove duplicates (IoU threshold 0.8)
    unique_boxes = remove_duplicates(predicted_boxes, iou_threshold=0.8)

    # 2. Snap edges within tolerance 0.01
    snapped_boxes = snap_boxes(unique_boxes, snap_tol=0.01)

    # 3. Resolve overlaps by iterative shifting
    refined_boxes = resolve_overlaps(snapped_boxes, iterations=200, move_step=0.002)

    # Normalize boxes for matching only (since semantic boxes are normalized)
    normalized_boxes = normalize_boxes(refined_boxes, norm_factor=1.0)  # Change norm_factor to 500 if pixel scale

    # 4. Match labels using normalized boxes
    room_labels = match_predicted_with_semantic(normalized_boxes, semantic_rooms, semantic_labels, iou_thresh=0.1)

    # 5. Merge refined boxes polygons
    merged_polys = unary_union(refined_boxes)
    if isinstance(merged_polys, Polygon):
        merged_polys = [merged_polys]
    else:
        merged_polys = list(merged_polys.geoms)

    # 6. Build adjacency graph on merged polygons
    adjacency_graph = build_adjacency_graph(merged_polys)

    # 7. Find doors based on semantic links & adjacency
    doors = find_doors_with_semantic_links(adjacency_graph, room_labels, semantic_links)

    # 8. Create lawn area surrounding the floorplan
    lawn = create_lawn(merged_polys, margin=0.02)

    # 9. Plot everything
    plot_floorplan_with_lawn(
        refined_boxes, merged_polys, doors, room_labels, lawn,
        title=f"Scene {scene_id} Floorplan with Semantic Labels, Doors, Lawn",
        save_path=f"floorplan_images/scene_{scene_id}_final_floorplan.png"
    )

    print("Floorplan generation complete. Check floorplan_images folder.")

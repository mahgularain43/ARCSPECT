import os
import random
import pickle
import argparse
from sklearn.model_selection import train_test_split

def get_all_ids(data_dir, suffix):
    ids = []
    for fname in os.listdir(data_dir):
        if fname.endswith(suffix):
            id_ = fname.replace(suffix, "").replace("_graph", "")
            ids.append(id_)
    return sorted(list(set(ids)))

def save_ids(ids, out_txt_path, out_pickle_path):
    with open(out_txt_path, "w") as f:
        for id_ in ids:
            f.write(f"{id_}\n")
    with open(out_pickle_path, "wb") as f:
        pickle.dump(ids, f)

def main(data_dir, suffix, output_dir, test_ratio=0.2):
    os.makedirs(output_dir, exist_ok=True)

    print(f"🔍 Searching for files in: {data_dir} with suffix '{suffix}'...")
    all_ids = get_all_ids(data_dir, suffix)
    print(f"📦 Found {len(all_ids)} unique sample IDs")

    train_ids, test_ids = train_test_split(all_ids, test_size=test_ratio, random_state=42)

    save_ids(train_ids, os.path.join(output_dir, "train_ids.txt"), os.path.join(output_dir, "train_ids.pickle"))
    save_ids(test_ids, os.path.join(output_dir, "test_ids.txt"), os.path.join(output_dir, "test_ids.pickle"))

    print(f"✅ Saved {len(train_ids)} train IDs and {len(test_ids)} test IDs to: {output_dir}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate train/test ID splits")
    parser.add_argument("--data_dir", type=str, default="data/linguistic", help="Directory with input .txt/.json files")
    parser.add_argument("--suffix", type=str, default=".txt", help="File suffix to match (e.g., .txt, .json)")
    parser.add_argument("--output_dir", type=str, default="data/splits", help="Output directory for split files")
    parser.add_argument("--test_ratio", type=float, default=0.2, help="Ratio of test samples")

    args = parser.parse_args()
    main(args.data_dir, args.suffix, args.output_dir, args.test_ratio)

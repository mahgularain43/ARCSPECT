# backend/scripts/generate_paraphrases.py

import os
from pathlib import Path
from transformers import pipeline

# === PATH SETUP ===
original_dir = r"C:\Users\HP\Desktop\project-root\backend\data\nlp_dataset\linguistic_expression"
augmented_dir = r"C:\Users\HP\Desktop\project-root\backend\data\nlp_dataset\linguistic_expression_augmented"

# Create augmented folder if it doesn't exist
Path(augmented_dir).mkdir(parents=True, exist_ok=True)

# Load Hugging Face T5 paraphrasing model
print("🔁 Loading paraphrasing model...")
paraphraser = pipeline("text2text-generation", model="ramsrigouthamg/t5_paraphraser", framework="pt")

# Get list of all .txt files in original dataset
txt_files = [f for f in os.listdir(original_dir) if f.endswith(".txt")]
print(f"✅ Found {len(txt_files)} files to paraphrase.\n")

# Generate paraphrased versions
for filename in txt_files:
    file_path = os.path.join(original_dir, filename)

    with open(file_path, "r", encoding="utf-8") as f:
        original = f.read().strip()

    if not original:
        continue

    prompt = f"paraphrase: {original} </s>"

    try:
        outputs = paraphraser(prompt, max_length=128, num_return_sequences=3, do_sample=True)

        # Save output file
        out_path = os.path.join(augmented_dir, filename)
        with open(out_path, "w", encoding="utf-8") as out_file:
            out_file.write(f"#Original:\n{original}\n\n")
            for i, o in enumerate(outputs, 1):
                out_file.write(f"#P{i}: {o['generated_text']}\n")

        print(f"✅ {filename} paraphrased and saved.")

    except Exception as e:
        print(f"❌ Failed to paraphrase {filename}: {str(e)}")

print("\n🎉 Paraphrasing complete.")
print(f"Augmented files saved to: {augmented_dir}")

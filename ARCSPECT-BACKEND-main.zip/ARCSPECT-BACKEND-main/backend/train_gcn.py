import os
import torch
import torch.nn as nn
from torch_geometric.loader import DataLoader
from parser.gcn_layout_model import GCNLayoutPredictor
from parser.scene_graph_to_pyg import load_all_graphs

# === Config ===
DATA_DIR = "backend/data/semantic_expression"
CHECKPOINT_PATH = "checkpoints/gcn_layout_model_spatial.pt"
BATCH_SIZE = 8
EPOCHS = 200
LR = 0.001
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("🖥 Using device:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")

# === Spatial loss to prevent overlaps ===
def spatial_loss(pred, margin=0.05):
    center = pred[:, :2]
    N = center.shape[0]
    loss = 0.0
    for i in range(N):
        for j in range(i + 1, N):
            dist = torch.norm(center[i] - center[j])
            if dist < margin:
                loss += (margin - dist) ** 2
    return loss / (N * (N - 1) / 2 + 1e-6)

# === Overlap-based loss (approximate) ===
def overlap_penalty(pred):
    x, y, w, h = pred[:, 0], pred[:, 1], pred[:, 2], pred[:, 3]
    x1 = x - w / 2
    y1 = y - h / 2
    x2 = x + w / 2
    y2 = y + h / 2
    N = pred.shape[0]
    penalty = 0.0
    for i in range(N):
        for j in range(i + 1, N):
            inter_x = max(0, min(x2[i], x2[j]) - max(x1[i], x1[j]))
            inter_y = max(0, min(y2[i], y2[j]) - max(y1[i], y1[j]))
            inter_area = inter_x * inter_y
            penalty += inter_area
    return penalty / (N * (N - 1) / 2 + 1e-6)

# === Training ===
def train():
    print("📂 Loading data from:", DATA_DIR)
    data_list = load_all_graphs(DATA_DIR)
    if not data_list:
        print("❌ No training data found.")
        return

    loader = DataLoader(data_list, batch_size=BATCH_SIZE, shuffle=True)
    model = GCNLayoutPredictor(node_input_dim=10, edge_attr_dim=2).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    mse_loss = nn.MSELoss()

    model.train()
    for epoch in range(1, EPOCHS + 1):
        total_loss = 0.0
        for batch in loader:
            batch = batch.to(device)
            optimizer.zero_grad()

            pred = model(batch)
            layout_loss = mse_loss(pred, batch.y)
            spread = spatial_loss(pred)
            overlap = overlap_penalty(pred)

            total = layout_loss + 0.1 * spread + 0.1 * overlap
            total.backward()
            optimizer.step()
            total_loss += total.item()

        avg_loss = total_loss / len(loader)
        print(f"📈 Epoch {epoch}/{EPOCHS} - Total Loss: {avg_loss:.4f}")

    os.makedirs(os.path.dirname(CHECKPOINT_PATH), exist_ok=True)
    torch.save(model.state_dict(), CHECKPOINT_PATH)
    print(f"✅ Model saved to {CHECKPOINT_PATH}")

if __name__ == "__main__":
    train()

from fastapi import Request, HTTPException

# Dummy version for now
def get_current_user(request: Request):
    token = request.headers.get("Authorization")
    if not token:
        raise HTTPException(status_code=401, detail="Missing token")

    # Normally decode JWT or validate token here
    return {"_id": "user-123", "email": "test@example.com"}

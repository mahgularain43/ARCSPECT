# utils/graph_utils.py

import numpy as np

# Standardized room types (can be expanded based on dataset)
ROOM_TYPES = ["bedroom", "kitchen", "bathroom", "livingroom", "balcony", "study", "washroom"]

def one_hot_room_vector(room):
    """
    Converts a room dictionary to a one-hot + numeric vector
    """
    vec = np.zeros(len(ROOM_TYPES) + 2)  # [room_types..., size, position]
    
    # One-hot encode room type
    if room["type"] in ROOM_TYPES:
        vec[ROOM_TYPES.index(room["type"])] = 1

    # Normalize and encode size
    vec[-2] = room.get("size", 10) / 100  # Normalized by 100

    # Encode position
    position_mapping = {
        "north": 0.1, "south": 0.2, "east": 0.3,
        "west": 0.4, "center": 0.5
    }
    vec[-1] = position_mapping.get(room.get("position", "center"), 0.5)

    return vec

def build_adjacency_matrix(num_nodes, edges):
    """
    Builds an NxN adjacency matrix from list of edges
    """
    A = np.eye(num_nodes)  # self-connections
    for i, j in edges:
        A[i][j] = 1
        A[j][i] = 1
    return A

# backend/utils/io.py

import os
import json
import pickle


def save_json(obj, path):
    """
    Save a Python object to a JSON file.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=4, ensure_ascii=False)


def load_json(path):
    """
    Load a JSON file into a Python object.
    """
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_pickle(obj, path):
    """
    Save a Python object to a pickle file.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(obj, f)


def load_pickle(path):
    """
    Load a Python object from a pickle file.
    """
    with open(path, "rb") as f:
        return pickle.load(f)


def load_ids(path):
    """
    Load ID list from a .txt or .pickle file.
    Returns a list of sample IDs as strings.
    """
    if path.endswith(".txt"):
        with open(path, "r") as f:
            return [line.strip() for line in f if line.strip()]
    elif path.endswith(".pickle"):
        with open(path, "rb") as f:
            data = pickle.load(f)
            return [str(i) for i in data]  # Ensure all are strings
    else:
        raise ValueError(f"Unsupported ID file format: {path}")

# backend/utils/loss.py

import torch.nn.functional as F

def compute_node_loss(node_logits, node_labels, loss_fn):
    """
    Compute node classification loss.
    Args:
        node_logits: (B, max_rooms, num_classes)
        node_labels: (B, max_rooms)
        loss_fn: CrossEntropyLoss instance
    Returns:
        scalar loss
    """
    B, N, C = node_logits.size()
    node_logits = node_logits.view(B * N, C)
    node_labels = node_labels.view(B * N)
    return loss_fn(node_logits, node_labels)

def compute_edge_loss(edge_logits, edge_labels, loss_fn):
    """
    Compute edge classification loss.
    Args:
        edge_logits: (B, max_rooms, max_rooms)
        edge_labels: (B, max_rooms, max_rooms)
        loss_fn: BCEWithLogitsLoss instance
    Returns:
        scalar loss
    """
    return loss_fn(edge_logits, edge_labels)

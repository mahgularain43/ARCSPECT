import os
import torch
import numpy as np
import matplotlib.pyplot as plt
from torch_geometric.loader import DataLoader
from parser.gcn_layout_model import GCNLayoutPredictor
from parser.scene_graph_to_pyg import load_all_graphs

# === Config ===
DATA_DIR = "backend/data/semantic_expression"
CHECKPOINT_PATH = "checkpoints/gcn_layout_model_spatial.pt"  # path to your uploaded model file
BATCH_SIZE = 1  # visualize one scene at a time
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def visualize_layouts(gt_boxes, predicted_boxes, scene_id, output_dir):
    plt.figure(figsize=(7, 7))
    ax = plt.gca()
    ax.set_title(f"Scene {scene_id:04d}")

    # Plot GT boxes (green, solid)
    for box in gt_boxes:
        rect = plt.Rectangle(
            (box[0], box[1]), box[2], box[3],
            fill=False, edgecolor="green", linewidth=3
        )
        ax.add_patch(rect)

    # Plot predicted boxes (red, dashed)
    for box in predicted_boxes:
        rect = plt.Rectangle(
            (box[0], box[1]), box[2], box[3],
            fill=False, edgecolor="red", linewidth=2, linestyle="dashed"
        )
        ax.add_patch(rect)

    plt.legend(["GT (Green)", "Predicted (Red)"])
    plt.xlim(0, 1)  # Assuming normalized coordinates, adjust if not
    plt.ylim(1, 0)  # Flip y-axis for correct visualization
    plt.axis("equal")

    os.makedirs(output_dir, exist_ok=True)
    plt.savefig(f"{output_dir}/scene_{scene_id:04d}.png")
    plt.close()

def bbox_from_pred(pred_tensor):
    # Convert model output to [x, y, w, h]
    # Model outputs: center_x, center_y, width, height (all normalized [0,1])
    pred = pred_tensor.detach().cpu().numpy()
    boxes = []
    for p in pred:
        cx, cy, w, h = p
        x = cx - w / 2
        y = cy - h / 2
        boxes.append([x, y, w, h])
    return boxes

def gt_boxes_from_batch(batch):
    # batch.y contains GT layout in [center_x, center_y, w, h]
    gt = batch.y.detach().cpu().numpy()
    boxes = []
    for g in gt:
        cx, cy, w, h = g
        x = cx - w / 2
        y = cy - h / 2
        boxes.append([x, y, w, h])
    return boxes

def main():
    print("🖥 Using device:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")

    data_list = load_all_graphs(DATA_DIR)
    if not data_list:
        print("❌ No data found.")
        return

    loader = DataLoader(data_list, batch_size=BATCH_SIZE, shuffle=False)
    model = GCNLayoutPredictor(node_input_dim=10, edge_attr_dim=2).to(device)
    model.load_state_dict(torch.load(CHECKPOINT_PATH, map_location=device))
    model.eval()

    output_vis_dir = "outputs/gcn_layout_visualizations"
    output_pred_dir = "outputs/predicted_boxes"
    os.makedirs(output_pred_dir, exist_ok=True)

    for i, batch in enumerate(loader):
        batch = batch.to(device)
        with torch.no_grad():
            pred = model(batch)

        pred_boxes = bbox_from_pred(pred)
        gt_boxes = gt_boxes_from_batch(batch)

        # Save predicted boxes for this scene
        np.save(f"{output_pred_dir}/predicted_boxes_scene_{i:04d}.npy", np.array(pred_boxes))

        visualize_layouts(gt_boxes, pred_boxes, i, output_vis_dir)
        print(f"✅ Visualized scene {i} saved, predicted boxes saved.")

        # For demo, visualize only first 10 scenes
        if i >= 9:
            break

if __name__ == "__main__":
    main()
